const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 1e6 });

// ---------- Konfigurasi dasar ----------
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || ''; // kosong = dashboard terbuka (cocok buat lokal)
const PUBLIC_DIR = path.join(__dirname, 'public');
const MEDIA_DIR = path.join(PUBLIC_DIR, 'media');
const DATA_DIR = path.join(__dirname, 'data');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
for (const d of [MEDIA_DIR, DATA_DIR]) { try { fs.mkdirSync(d, { recursive: true }); } catch (e) { console.error('Gagal buat folder', d, e.message); } }

// ---------- Pengaturan (disimpan ke data/settings.json) ----------
const ROW_GIFT = { id: '', enabled: true, gift: '*', minDiamond: 0, alertText: '', alertSub: '', ttsText: '', sound: '', media: '', duration: 6, volume: 1, keepDefault: false };
const ROW_CMD = { id: '', enabled: true, cmd: '!info', alertText: '', alertSub: '', ttsText: '', sound: '', media: '', duration: 6, volume: 1, cooldown: 10 };
const ROW_SND = { id: '', enabled: true, gift: '*', minDiamond: 0, sound: '', volume: 1 };
const ROW_REM = { id: '', enabled: true, every: 5, alertText: '', alertSub: '', ttsText: '', sound: '', duration: 6 };
const evDef = (o) => ({ alert: true, tts: false, alertText: '', alertSub: '', ttsText: '', sound: '', duration: 5, ...o });

const DEFAULTS = {
  connection: { autoReconnect: true, autoStart: false, lastUser: '', myUser: '', waitLive: true },
  voice: { engine: 'browser', name: '', lang: 'id-ID', rate: 1, pitch: 1, volume: 1, maxLen: 120 },
  filter: { blacklist: '', skipLinks: true },
  events: {
    gift: evDef({ tts: true, minDiamond: 1, alertText: '{nick} kirim {gift} ×{count}', alertSub: '{diamonds} diamond', ttsText: '{nick} mengirim {count} {gift}. Terima kasih!' }),
    follow: evDef({ tts: true, duration: 4, alertText: '{nick} mulai mengikuti', alertSub: 'Selamat datang!', ttsText: '{nick} follow. Terima kasih!' }),
    share: evDef({ duration: 4, alertText: '{nick} membagikan live', alertSub: 'Makasih udah share!', ttsText: 'Terima kasih {nick} sudah share' }),
    subscribe: evDef({ tts: true, duration: 6, alertText: '{nick} jadi subscriber', alertSub: 'Terima kasih dukungannya!', ttsText: 'Terima kasih {nick} sudah subscribe' }),
    join: evDef({ alert: false, duration: 3, gap: 8, alertText: '{nick} masuk ke live', alertSub: '', ttsText: 'Selamat datang {nick}' }),
    like: evDef({ every: 500, duration: 4, alertText: '{total} like tercapai!', alertSub: 'Makasih semuanya', ttsText: 'Yey, {total} like tercapai' }),
    chat: { tts: false, ttsText: '{nick} bilang {text}', prefix: '', minLen: 2, cooldown: 2, skipCommands: true, only: 'all' },
  },
  look: { theme: 'klasik', accent: '', font: 'bawaan', anim: 'pop', textScale: 1, widgetStyle: 'kaca', effect: 'none', bigMin: 100, bigTheme: 'emas', bigEffect: 'confetti', bigScale: 1.3, bigDuration: 8, bigSound: '', bigAlertText: '{nick} kirim {gift} ×{count}', bigAlertSub: '{diamonds} diamond - makasih banyak!', bigTtsText: 'Wow! {nick} mengirim {count} {gift}. Terima kasih banyak!' },
  giftSounds: [],
  giftActions: [],
  commands: [],
  reminders: [
    { id: 'rem_tap', enabled: false, every: 4, alertText: 'Tap tap layarnya ya!', alertSub: 'Bantu naikin like live ini', ttsText: 'Jangan lupa tap tap layarnya ya, biar live ini makin rame', sound: '', duration: 6 },
    { id: 'rem_follow', enabled: false, every: 7, alertText: 'Follow dulu dong', alertSub: 'Biar nggak ketinggalan live berikutnya', ttsText: 'Yang belum follow, jangan lupa follow ya', sound: '', duration: 6 },
  ],
  music: { volume: 0.5, shuffle: false, repeat: 'all', duck: true, duckLevel: 0.25, playlists: [{ id: 'pl_default', name: 'Musik Bawaan', tracks: ['/music/lofi.mp3', '/music/ceria.mp3', '/music/tenang.mp3'] }] },
  goals: {
    diamond: { title: 'Target Diamond', target: 1000 },
    likes: { title: 'Target Like', target: 5000 },
    followers: { title: 'Target Follower', target: 50 },
  },
  timer: { title: 'Sisa waktu', start: 600, perDiamond: 1, perFollow: 10, perShare: 5, max: 0 },
  poll: { announce: true },
  wheel: { enabled: false, title: 'Roda Hadiah', items: 'Shoutout spesial\nNyanyi 1 lagu\nPush up 5x\nJoget 10 detik\nZonk, coba lagi', gift: '', minDiamond: 1, sound: '', ttsText: 'Selamat {nick}, hadiahnya {prize}' },
  giveaway: { keyword: '!ikut', announceText: 'Selamat {nick}, kamu pemenang giveaway!' },
};

const clone = (o) => JSON.parse(JSON.stringify(o));
function merge(base, patch) {
  if (Array.isArray(base)) return Array.isArray(patch) ? patch.slice(0, 300) : base;
  if (base && typeof base === 'object') {
    const out = { ...base };
    if (patch && typeof patch === 'object') for (const k of Object.keys(base)) if (k in patch) out[k] = merge(base[k], patch[k]);
    return out;
  }
  if (typeof base === 'number') { const n = Number(patch); return Number.isFinite(n) ? n : base; }
  if (typeof base === 'boolean') return !!patch;
  return String(patch ?? '').slice(0, 600);
}
const rid = () => 'r' + Math.random().toString(36).slice(2, 9);
function sanitize(s) {
  s.giftActions = (s.giftActions || []).map(r => { const c = merge(ROW_GIFT, r); c.id = c.id || rid(); return c; });
  s.commands = (s.commands || []).map(r => { const c = merge(ROW_CMD, r); c.id = c.id || rid(); return c; });
  s.giftSounds = (s.giftSounds || []).map(r => { const c = merge(ROW_SND, r); c.id = c.id || rid(); return c; });
  s.reminders = (s.reminders || []).map(r => { const c = merge(ROW_REM, r); c.id = c.id || rid(); c.every = Math.max(1, c.every); return c; });
  s.music.playlists = (s.music.playlists || []).slice(0, 30).map(p => ({ id: String(p.id || rid()).slice(0, 24), name: String(p.name || 'Playlist').slice(0, 60), tracks: (Array.isArray(p.tracks) ? p.tracks : []).map(t => String(t).slice(0, 200)).filter(t => /^\/(media|music)\//.test(t)).slice(0, 200) }));
  if (!['off', 'all', 'one'].includes(s.music.repeat)) s.music.repeat = 'all';
  s.music.volume = Math.min(1, Math.max(0, s.music.volume)); s.music.duckLevel = Math.min(1, Math.max(0, s.music.duckLevel));
  return s;
}
let cfg;
try { cfg = sanitize(merge(clone(DEFAULTS), JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')))); }
catch { cfg = sanitize(clone(DEFAULTS)); }
let saveTimer = null;
const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => fs.writeFile(SETTINGS_FILE, JSON.stringify(cfg, null, 2), () => {}), 400); };

// ---------- State live ----------
const newState = () => ({ diamonds: 0, likes: 0, likeGain: 0, followers: 0, shares: 0, gifts: 0, chats: 0, viewers: 0, connected: false, user: '' });
const state = newState();
let goalBase = { diamonds: 0, likes: 0, followers: 0 };
const gifters = {}, likers = {}, chatters = {};
// Gift yang pernah masuk (buat daftar pilihan + ikon di dashboard)
const GIFTS_FILE = path.join(DATA_DIR, 'gifts.json');
let seenGifts = {}; try { seenGifts = JSON.parse(fs.readFileSync(GIFTS_FILE, 'utf8')); } catch {}
let giftsTimer = null;
const rememberGift = (name, unit, img) => {
  if (!name) return; const k = String(name).toLowerCase(), g = seenGifts[k] || (seenGifts[k] = { name: String(name) });
  g.diamonds = unit || g.diamonds || 0; if (img) g.img = img;
  const keys = Object.keys(seenGifts); if (keys.length > 500) delete seenGifts[keys[0]];
  clearTimeout(giftsTimer); giftsTimer = setTimeout(() => { fs.writeFile(GIFTS_FILE, JSON.stringify(seenGifts), () => {}); io.emit('gifts', Object.values(seenGifts)); }, 800);
};
const clearObj = (o) => Object.keys(o).forEach(k => delete o[k]);
let likeMile = null;
const joinSeen = new Set();
let lastJoinCue = 0;
const cmdLast = {}, chatLast = {};

const board = (obj, key) => Object.values(obj).sort((a, b) => b[key] - a[key]).slice(0, 10);
const publicState = () => ({
  ...state,
  top: board(gifters, 'diamonds'), topLikers: board(likers, 'likes'), topChat: board(chatters, 'msgs'),
  goal: { diamond: state.diamonds - goalBase.diamonds, likes: state.likeGain - goalBase.likes, followers: state.followers - goalBase.followers },
});
const throttle = (fn, ms) => { let t = 0, pend = false; return () => { const n = Date.now(); if (n - t >= ms) { t = n; fn(); } else if (!pend) { pend = true; setTimeout(() => { pend = false; t = Date.now(); fn(); }, ms - (n - t)); } }; };
const pushState = throttle(() => io.emit('state', publicState()), 250);
const pushNow = () => io.emit('state', publicState());

const emit = (type, data) => io.emit('event', { type, ...data, t: Date.now() });
let cueSeq = 0;
const sendCue = (c) => io.emit('cue', { id: ++cueSeq, ...c });

// ---------- Helper teks ----------
const fill = (t, v) => String(t || '').replace(/\{(\w+)\}/g, (_, k) => (v[k] ?? ''));
const EMOJI = /[\p{Extended_Pictographic}\u200d\ufe0f]/gu;
const cleanFrag = (s) => {
  let t = String(s ?? '');
  if (cfg.filter.skipLinks) t = t.replace(/https?:\/\/\S+|www\.\S+/gi, '');
  return t.replace(EMOJI, '').replace(/\s+/g, ' ').trim();
};
function ttsFor(tpl, v) {
  if (!tpl) return '';
  const vt = { ...v };
  for (const k of ['text', 'args']) if (vt[k] != null) vt[k] = cleanFrag(vt[k]).slice(0, cfg.voice.maxLen);
  for (const k of ['nick', 'gift']) if (vt[k] != null) vt[k] = cleanFrag(vt[k]).slice(0, 40);
  const out = cleanFrag(fill(tpl, vt)).slice(0, 400);
  const low = out.toLowerCase();
  const bl = cfg.filter.blacklist.split(/[,\n]/).map(x => x.trim().toLowerCase()).filter(Boolean);
  if (bl.some(w => low.includes(w))) return '';
  return out;
}

// ---------- Cue (instruksi yang diputar halaman alerts.html) ----------
function styleFor(type, tier) {
  const L = cfg.look, big = type === 'gift' && tier === 'big';
  return { theme: big ? L.bigTheme : L.theme, effect: big ? L.bigEffect : L.effect, scale: big ? L.bigScale : 1, tier: big ? 'big' : 'normal' };
}
function eventCue(type, v, tier, snd) {
  const E = cfg.events[type]; if (!E) return;
  const L = cfg.look, big = type === 'gift' && tier === 'big';
  const c = { type, ...styleFor(type, tier) };
  if (E.alert) {
    const own = big && L.bigAlertText;
    c.title = fill(own ? L.bigAlertText : E.alertText, v); c.sub = fill(own ? L.bigAlertSub : E.alertSub, v);
    c.img = v.giftImg || v.avatar || ''; c.duration = big ? L.bigDuration : E.duration;
  }
  const sfx = (snd && snd.sound) || (big && L.bigSound) || E.sound; if (sfx) c.sound = sfx;
  if (snd && snd.sound) c.volume = snd.volume;
  if (E.tts) { const t = ttsFor((big && L.bigTtsText) || E.ttsText, v); if (t) c.tts = t; }
  if (c.title || c.sound || c.tts) { sendCue(c); return true; }
  return false;
}
function rowCue(type, a, v, tier, snd) {
  const c = { type, ...styleFor(type, tier), title: fill(a.alertText, v), sub: fill(a.alertSub, v), img: v.giftImg || v.avatar || '', media: a.media || '', sound: a.sound || (snd && snd.sound) || '', duration: a.duration, volume: a.sound ? a.volume : (snd ? snd.volume : a.volume) };
  const t = ttsFor(a.ttsText, v); if (t) c.tts = t;
  if (c.title || c.media || c.sound || c.tts) sendCue(c);
}
function pickSound(giftName, diamonds) {
  const n = String(giftName || '').toLowerCase().trim();
  const ok = cfg.giftSounds.filter(r => r.enabled && r.sound && diamonds >= r.minDiamond);
  const exact = ok.filter(r => r.gift.trim().toLowerCase() === n).sort((a, b) => b.minDiamond - a.minDiamond);
  const any = ok.filter(r => ['*', ''].includes(r.gift.trim())).sort((a, b) => b.minDiamond - a.minDiamond);
  return exact[0] || any[0] || null;
}
function pickAction(giftName, diamonds) {
  const n = String(giftName || '').toLowerCase();
  const ok = cfg.giftActions.filter(a => a.enabled && diamonds >= a.minDiamond);
  const exact = ok.filter(a => a.gift.trim().toLowerCase() === n).sort((a, b) => b.minDiamond - a.minDiamond);
  const any = ok.filter(a => ['*', ''].includes(a.gift.trim())).sort((a, b) => b.minDiamond - a.minDiamond);
  return exact[0] || any[0] || null;
}

// ---------- Timer ----------
const timer = { started: false, running: false, endsAt: 0, remaining: 0 };
const timerView = (extra = {}) => ({ started: timer.started, running: timer.running, endsAt: timer.endsAt, remaining: timer.running ? Math.max(0, timer.endsAt - Date.now()) : timer.remaining, now: Date.now(), title: cfg.timer.title, ...extra });
const pushTimer = (extra) => io.emit('timer', timerView(extra));
function timerAdd(sec) {
  if (!timer.started || !sec) return;
  const cap = cfg.timer.max > 0 ? cfg.timer.max * 1000 : Infinity;
  if (timer.running) { const base = Math.max(Date.now(), timer.endsAt); timer.endsAt = Math.min(base + sec * 1000, Date.now() + cap); if (sec < 0) timer.endsAt = Math.max(Date.now(), timer.endsAt); }
  else timer.remaining = Math.min(cap, Math.max(0, timer.remaining + sec * 1000));
  pushTimer({ added: Math.round(sec) });
}

// ---------- Poll ----------
let poll = { visible: false, active: false, question: '', options: [], total: 0, endsAt: 0 };
const votes = {};
let pollTO = null;
const pollView = () => ({ ...poll, now: Date.now() });
const pushPoll = throttle(() => io.emit('poll', pollView()), 300);
function pollStop() {
  if (!poll.active) return;
  clearTimeout(pollTO); poll.active = false; poll.endsAt = 0; io.emit('poll', pollView());
  const best = [...poll.options].sort((a, b) => b.votes - a.votes)[0];
  if (cfg.poll.announce && best && best.votes > 0) { const t = cleanFrag(`Voting selesai. Pilihan ${best.label} menang dengan ${best.votes} suara`); sendCue({ type: 'poll', tts: t }); }
}
function pollStart({ question, options, duration }) {
  const opts = (options || []).map(o => String(o).trim().slice(0, 60)).filter(Boolean).slice(0, 9);
  if (opts.length < 2) return emit('system', { text: 'Poll butuh minimal 2 pilihan' });
  clearTimeout(pollTO); clearObj(votes);
  const dur = Math.max(0, Number(duration) || 0);
  poll = { visible: true, active: true, question: String(question || '').slice(0, 120), options: opts.map(label => ({ label, votes: 0 })), total: 0, endsAt: dur ? Date.now() + dur * 1000 : 0 };
  if (dur) pollTO = setTimeout(pollStop, dur * 1000);
  io.emit('poll', pollView());
}
function pollVote(user, idx) {
  if (!poll.active || !user || idx < 0 || idx >= poll.options.length) return;
  if (votes[user] === idx) return;
  if (votes[user] != null) poll.options[votes[user]].votes--; else poll.total++;
  votes[user] = idx; poll.options[idx].votes++; pushPoll();
}

// ---------- Giveaway ----------
let gw = { active: false, keyword: '', entries: {}, winners: [] };
const gwView = () => ({ active: gw.active, keyword: gw.keyword, count: Object.keys(gw.entries).length, winners: gw.winners, names: Object.values(gw.entries).map(e => e.nick).slice(0, 60) });
const pushGw = throttle(() => io.emit('giveaway', gwView()), 400);
function gwDraw(from) {
  const winnersSet = new Set(gw.winners.map(w => w.user));
  const pool = (from === 'gifters' ? Object.entries(gifters).filter(([, g]) => g.diamonds > 0).map(([user, g]) => ({ user, nick: g.nick, avatar: g.avatar })) : Object.entries(gw.entries).map(([user, e]) => ({ user, ...e }))).filter(p => !winnersSet.has(p.user));
  if (!pool.length) return emit('system', { text: 'Tidak ada peserta yang bisa diundi' });
  const w = pool[Math.floor(Math.random() * pool.length)];
  gw.winners.push(w);
  io.emit('giveaway', gwView());
  io.emit('giveawayWinner', { ...w, names: pool.map(p => p.nick).slice(0, 40) });
  const t = ttsFor(cfg.giveaway.announceText, w);
  if (t) setTimeout(() => sendCue({ type: 'giveaway', tts: t }), 4200);
}

// ---------- Handler event (dipakai live & tombol tes) ----------
// ---------- Roda putar (spin wheel) ----------
const wheelQ = []; let wheelBusy = false;
function wheelItems() { return String(cfg.wheel.items || '').split('\n').map(x => x.trim()).filter(Boolean).slice(0, 16); }
function wheelSpin(by) {
  if (wheelItems().length < 2) return emit('system', { text: 'Roda butuh minimal 2 hadiah (isi di tab Roda Putar).' });
  if (wheelQ.length < 10) wheelQ.push({ nick: (by && by.nick) || '' }); wheelRun();
}
function wheelRun() {
  if (wheelBusy || !wheelQ.length) return; wheelBusy = true;
  const j = wheelQ.shift(), items = wheelItems(), win = Math.floor(Math.random() * items.length);
  io.emit('wheel', { title: cfg.wheel.title, items, win, nick: j.nick, ms: 6000 });
  setTimeout(() => sendCue({ type: 'wheel', sound: cfg.wheel.sound, tts: ttsFor(cfg.wheel.ttsText, { nick: j.nick || 'buat kamu', prize: items[win] }) }), 6200);
  setTimeout(() => { wheelBusy = false; wheelRun(); }, 12500);
}
const wheelMatch = (gift, diamonds) => cfg.wheel.enabled && diamonds >= (cfg.wheel.minDiamond || 0) && (!cfg.wheel.gift.trim() || cfg.wheel.gift.trim().toLowerCase() === String(gift).toLowerCase());

function onGift(w, gift, count, diamonds, giftImg, test) {
  const v = { ...w, gift, count, diamonds, giftImg };
  if (!test) {
    state.diamonds += diamonds; state.gifts++;
    if (w.user) { const g = gifters[w.user] = gifters[w.user] || { nick: w.nick, avatar: w.avatar, diamonds: 0 }; g.diamonds += diamonds; }
    timerAdd(diamonds * cfg.timer.perDiamond); pushState();
    rememberGift(gift, Math.round(diamonds / Math.max(1, count)), giftImg);
  }
  emit('gift', v);
  if (wheelMatch(gift, diamonds)) wheelSpin(w);
  const tier = cfg.look.bigMin > 0 && diamonds >= cfg.look.bigMin ? 'big' : 'normal';
  const act = pickAction(gift, diamonds), snd = pickSound(gift, diamonds);
  if (act) rowCue('gift', act, v, tier, snd);
  let sent = false;
  if ((!act || act.keepDefault) && diamonds >= cfg.events.gift.minDiamond) sent = eventCue('gift', v, tier, act ? null : snd);
  if (snd && !act && !sent) sendCue({ type: 'gift', sound: snd.sound, volume: snd.volume });
}
function onFollow(w, test) {
  if (!test) { state.followers++; timerAdd(cfg.timer.perFollow); pushState(); }
  emit('follow', w); eventCue('follow', w);
}
function onShare(w, test) {
  if (!test) { state.shares++; timerAdd(cfg.timer.perShare); pushState(); }
  emit('share', w); eventCue('share', w);
}
function onSubscribe(w) { emit('subscribe', w); eventCue('subscribe', w); }
function onJoin(w, test) {
  emit('join', w);
  const E = cfg.events.join;
  if (!(E.alert || E.tts)) return;
  if (!test) {
    const key = w.user || w.nick;
    if (joinSeen.has(key)) return; joinSeen.add(key);
    if (Date.now() - lastJoinCue < E.gap * 1000) return; lastJoinCue = Date.now();
  }
  eventCue('join', w);
}
function onLike(w, batch, total, test) {
  if (test) return eventCue('like', { ...w, total: cfg.events.like.every });
  if (total > 0) state.likes = total; else state.likes += batch;
  const gain = batch || 0; state.likeGain += gain;
  if (w.user && gain) { const l = likers[w.user] = likers[w.user] || { nick: w.nick, avatar: w.avatar, likes: 0 }; l.likes += gain; }
  const E = cfg.events.like;
  if (E.every > 0 && state.likes > 0) {
    const m = Math.floor(state.likes / E.every);
    if (likeMile === null) likeMile = m;
    else if (m > likeMile) { likeMile = m; eventCue('like', { ...w, total: m * E.every }); }
  }
  pushState();
}
function runCommands(w, text) {
  const t = text.trim(), first = t.split(/\s+/)[0].toLowerCase(), args = t.slice(first.length).trim();
  for (const c of cfg.commands) {
    if (!c.enabled || !c.cmd || c.cmd.trim().toLowerCase() !== first) continue;
    const now = Date.now(), key = c.id;
    if (now - (cmdLast[key] || 0) < c.cooldown * 1000) return true;
    cmdLast[key] = now;
    rowCue('command', c, { ...w, args, text }); return true;
  }
  return false;
}
function onChat(w, text, test) {
  emit('chat', { ...w, text });
  if (!test) {
    state.chats++;
    if (w.user) { const c = chatters[w.user] = chatters[w.user] || { nick: w.nick, avatar: w.avatar, msgs: 0 }; c.msgs++; }
    pushState();
    const m = text.trim().match(/^!?(?:vote\s*)?([1-9])$/i);
    if (m) pollVote(w.user || w.nick, Number(m[1]) - 1);
    if (gw.active && w.user && text.trim().toLowerCase() === gw.keyword.toLowerCase()) { gw.entries[w.user] = { nick: w.nick, avatar: w.avatar }; pushGw(); }
  }
  const isCmd = runCommands(w, text);
  const E = cfg.events.chat;
  if (!E.tts || (isCmd && E.skipCommands) || (E.skipCommands && text.trim().startsWith('!'))) return;
  const need = { follower: ['follower', 'sub', 'mod'], subscriber: ['sub'], moderator: ['mod'], gifter: ['gifter'] }[E.only];
  if (need && !need.some(b => (w.badges || []).includes(b))) return;
  let body = text.trim();
  if (E.prefix) { if (!body.toLowerCase().startsWith(E.prefix.toLowerCase())) return; body = body.slice(E.prefix.length).trim(); }
  if (cleanFrag(body).length < E.minLen) return;
  const key = w.user || w.nick;
  if (!test && Date.now() - (chatLast[key] || 0) < E.cooldown * 1000) return;
  chatLast[key] = Date.now();
  const t = ttsFor(E.ttsText, { ...w, text: body });
  if (t) sendCue({ type: 'chat', tts: t });
}

// ---------- Helper pembaca data TikTok (library v2 menyimpan data bersarang) ----------
const urlOf = x => { const a = x?.urlList ?? x?.url ?? x?.urls ?? x; return Array.isArray(a) ? (a[0] || '') : (typeof a === 'string' ? a : ''); };
const num = v => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const badgesOf = (i) => [i.isModeratorOfAnchor && 'mod', i.isSubscriberOfAnchor && 'sub', (i.isFollowerOfAnchor || i.isMutualFollowingWithAnchor) && 'follower', i.isGiftGiverOfAnchor && 'gifter'].filter(Boolean);
const who = d => {
  const u = d.user ?? d.common?.displayText?.pieces?.find(p => p.userValue?.user)?.userValue?.user ?? {};
  return {
    user: u.uniqueId ?? u.displayId ?? d.uniqueId ?? String(u.id ?? ''),
    nick: u.nickname ?? d.nickname ?? '',
    avatar: urlOf(u.avatarThumb) || urlOf(u.avatarMedium) || urlOf(u.profilePicture) || d.profilePictureUrl || '',
    badges: badgesOf(d.userIdentity || u.userIdentity || {}),
  };
};

// Cetak contoh data tiap jenis event sekali di terminal (buat debug)
const seen = new Set();
const SKIP = ['avatarThumb', 'avatarMedium', 'avatarLarge', 'displayText', 'badgeList', 'badgeImageList', 'userVipInfo', 'common'];
const peek = (t, d) => { if (seen.has(t)) return; seen.add(t);
  try {
    console.log(`[contoh event: ${t}]`, JSON.stringify(d, (k, v) => {
      if (typeof v === 'bigint') return v.toString();
      if (SKIP.includes(k)) return '[...]';
      if (k === 'user' && v && typeof v === 'object') return { nickname: v.nickname, displayId: v.displayId, uniqueId: v.uniqueId };
      if (typeof v === 'string' && v.length > 60) return v.slice(0, 40) + '...';
      return v;
    }).slice(0, 2500));
  } catch {}
};

// Terima username, @username, atau link TikTok lengkap
function cleanName(raw) {
  let u = String(raw || '').trim();
  const m = u.match(/tiktok\.com\/@?([^/?#\s]+)/i);
  if (m) u = m[1];
  return u.replace(/^@/, '');
}

// ---------- Pengingat otomatis (ajak tap-tap, follow, share, dll) ----------
const remLast = {};
setInterval(() => {
  if (!state.connected) return;
  const now = Date.now();
  for (const r of cfg.reminders) {
    if (!r.enabled) continue;
    if (remLast[r.id] === undefined) { remLast[r.id] = now; continue; }
    if (now - remLast[r.id] >= r.every * 60000) { remLast[r.id] = now; rowCue('reminder', r, { nick: '', user: '', avatar: '' }); }
  }
}, 10000);

// ---------- Musik & playlist (diputar oleh overlay music.html) ----------
const music = { playing: false, pl: '', order: [], pos: 0, seq: 0, errs: 0 };
const curPlaylist = () => cfg.music.playlists.find(p => p.id === music.pl);
function buildOrder(n, shuffle, first) {
  const o = [...Array(n).keys()];
  if (shuffle) { for (let i = n - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [o[i], o[j]] = [o[j], o[i]]; } if (first != null) { const k = o.indexOf(first); [o[0], o[k]] = [o[k], o[0]]; } }
  return o;
}
function musicView() {
  const pl = curPlaylist(), cur = pl && music.order.length ? music.order[Math.min(music.pos, music.order.length - 1)] : 0;
  return { playing: music.playing && !!pl, pl: music.pl, plName: pl ? pl.name : '', tracks: pl ? pl.tracks : [], cur, seq: music.seq, ...cfg.music, playlists: undefined };
}
const pushMusic = () => io.emit('music', musicView());
function musicFix() { // rapikan state kalau playlist/lagu berubah
  const pl = curPlaylist();
  if (!pl || !pl.tracks.length) { music.playing = false; music.order = []; return; }
  if (music.order.length !== pl.tracks.length || music.order.some(i => i >= pl.tracks.length)) { music.order = buildOrder(pl.tracks.length, cfg.music.shuffle, music.order[music.pos]); music.pos = 0; }
}
function musicPlay(plId, index) {
  const pl = cfg.music.playlists.find(p => p.id === (plId || music.pl)) || cfg.music.playlists.find(p => p.tracks.length);
  if (!pl || !pl.tracks.length) return emit('system', { text: 'Playlist kosong. Tambahkan lagu dulu di tab Musik.' });
  const i = Math.min(Math.max(0, Number(index) || 0), pl.tracks.length - 1);
  music.pl = pl.id; music.order = buildOrder(pl.tracks.length, cfg.music.shuffle, i); music.pos = cfg.music.shuffle ? 0 : i;
  music.playing = true; music.seq++; music.errs = 0; pushMusic();
}
function musicStep(dir, auto) {
  const pl = curPlaylist(); if (!pl || !pl.tracks.length) return;
  if (auto && cfg.music.repeat === 'one') { music.seq++; return pushMusic(); }
  let p = music.pos + dir;
  if (p >= music.order.length) { if (auto && cfg.music.repeat === 'off') { music.playing = false; return pushMusic(); } music.order = buildOrder(pl.tracks.length, cfg.music.shuffle); p = 0; }
  if (p < 0) p = music.order.length - 1;
  music.pos = p; music.playing = true; music.seq++; pushMusic();
}

// ---------- Koneksi ke TikTok LIVE ----------
let conn = null, wantUser = '', retry = 0, retryTimer = null, ended = false;

function resetSession() {
  Object.assign(state, newState());
  goalBase = { diamonds: 0, likes: 0, followers: 0 };
  clearObj(gifters); clearObj(likers); clearObj(chatters); joinSeen.clear(); likeMile = null;
}
function dropConn() { if (conn) { const c = conn; conn = null; try { c.disconnect(); } catch {} } }
function scheduleRetry() {
  if (!cfg.connection.autoReconnect || !wantUser || ended) return;
  if (++retry > 8) { wantUser = ''; return emit('system', { text: 'Gagal menyambung ulang setelah 8 kali coba. Klik Sambungkan lagi.' }); }
  const sec = Math.min(60, retry * 5);
  emit('system', { text: `Koneksi terputus, mencoba lagi dalam ${sec} detik (percobaan ${retry}/8)` });
  clearTimeout(retryTimer);
  retryTimer = setTimeout(() => connect(wantUser, { keep: true }), sec * 1000);
}

async function connect(raw, opts = {}) {
  const username = cleanName(raw);
  clearTimeout(retryTimer); dropConn();
  if (!username) return;
  wantUser = username; ended = false;
  if (!opts.keep) { retry = 0; resetSession(); clearObj(remLast); }
  state.user = username; state.connected = false; pushNow();
  cfg.connection.lastUser = username; saveSoon();

  let lib;
  try { lib = await import('tiktok-live-connector'); }
  catch (e) { console.error(e); return emit('system', { text: 'Library gagal dimuat: ' + String(e?.message || e).slice(0, 200) + ' (cek versi Node, butuh 20 atau lebih baru)' }); }
  const E = lib.WebcastEvent || {};
  const ev = (k, fallback) => E[k] || fallback;

  const Conn = lib.TikTokLiveConnection;
  const opt = {};
  if (process.env.EULER_API_KEY) opt.signApiKey = process.env.EULER_API_KEY;
  // Opsional: login pakai akun sendiri (sessionid cookie TikTok) lewat variabel TIKTOK_SESSIONID + TIKTOK_TT_TARGET_IDC
  if (process.env.TIKTOK_SESSIONID && process.env.TIKTOK_TT_TARGET_IDC) opt.session = { cookie: { type: 'cookie', value: { sessionId: process.env.TIKTOK_SESSIONID, ttTargetIdc: process.env.TIKTOK_TT_TARGET_IDC } } };
  const me = new Conn(username, opt);
  conn = me;
  const on = (t, fn) => me.on(t, d => { if (conn !== me) return; peek(t, d); try { fn(d); } catch (e) { console.error('Error handler', t, e); } });

  on(ev('CHAT', 'chat'), d => onChat(who(d), String(d.comment ?? d.content ?? d.message ?? d.text ?? '')));
  on(ev('MEMBER', 'member'), d => onJoin(who(d)));
  on(ev('FOLLOW', 'follow'), d => onFollow(who(d)));
  on(ev('SHARE', 'share'), d => onShare(who(d)));
  on(ev('SUB_NOTIFY', 'subNotify'), d => onSubscribe(who(d)));
  on(ev('LIKE', 'like'), d => onLike(who(d), num(d.likeCount ?? d.count), num(d.totalLikeCount ?? d.total ?? d.totalLikes ?? d.likeTotal)));
  on(ev('ROOM_USER', 'roomUser'), d => { // 'total' = penonton saat ini; 'totalUser' = akumulasi semua yang pernah masuk
    state.viewers = num(d.viewerCount ?? d.total ?? d.viewers) || state.viewers; pushState(); });
  on(ev('GIFT', 'gift'), d => {
    const g = d.giftDetails ?? d.gift ?? d;
    const repeat = num(d.repeatCount) || 1;
    // Gift beruntun (streak): hitung hanya saat streak selesai
    if (num(g.giftType ?? g.type) === 1 && !num(d.repeatEnd)) return;
    const diamonds = num(g.diamondCount ?? g.diamond_count) * repeat;
    onGift(who(d), g.giftName ?? g.name ?? 'Gift', repeat, diamonds, g.giftImage?.giftPictureUrl || urlOf(g.giftImage) || urlOf(g.image) || urlOf(g.icon) || g.giftPictureUrl || '');
  });
  on(ev('STREAM_END', 'streamEnd'), () => { ended = true; state.connected = false; pushNow(); emit('system', { text: 'Live berakhir' }); });
  me.on('error', e => console.error('Koneksi error:', e?.message || e));
  me.on('disconnected', () => { if (conn !== me) return; state.connected = false; pushNow(); scheduleRetry(); });

  try {
    await me.connect();
    if (conn !== me) return;
    state.connected = true; retry = 0; pushNow();
    emit('system', { text: `Tersambung ke @${username}` });
  } catch (err) {
    if (conn !== me) return;
    state.connected = false; pushNow();
    const msg = String(err?.message || err).split('; URL:')[0].slice(0, 200);
    const offline = /offline|not live|isn't live|LIVE has ended|UserOffline/i.test(String(err?.name || '') + ' ' + String(err?.message || ''));
    if (cfg.connection.waitLive && wantUser === username && (offline || opts.wait)) {
      if (!opts.wait) emit('system', { text: `@${username} belum LIVE. Menunggu... akan nyambung otomatis begitu kamu mulai live (cek tiap 20 detik).` });
      clearTimeout(retryTimer);
      retryTimer = setTimeout(() => { if (wantUser === username && !conn) connect(username, { keep: true, wait: true }); }, 20000);
      return;
    }
    emit('system', { text: `Gagal konek: ${msg}. Pastikan @${username} sedang LIVE.` });
    if (opts.keep) scheduleRetry();
  }
}

// ---------- HTTP: TTS Google, media, upload ----------
const ttsCache = new Map();
app.get('/tts', async (req, res) => {
  const text = String(req.query.text || '').slice(0, 200);
  const lang = String(req.query.lang || 'id').replace(/[^a-zA-Z-]/g, '').slice(0, 8) || 'id';
  if (!text.trim()) return res.status(400).end();
  const key = lang + '|' + text;
  try {
    let buf = ttsCache.get(key);
    if (!buf) {
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${encodeURIComponent(lang)}&q=${encodeURIComponent(text)}`;
      const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(8000) });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      buf = Buffer.from(await r.arrayBuffer());
      if (ttsCache.size > 200) ttsCache.delete(ttsCache.keys().next().value);
      ttsCache.set(key, buf);
    }
    res.set({ 'Content-Type': 'audio/mpeg', 'Cache-Control': 'public, max-age=86400' }).send(buf);
  } catch (e) { res.status(502).end('TTS gagal: ' + (e.message || e)); }
});

const EXT = { audio: ['mp3', 'wav', 'ogg', 'm4a'], image: ['gif', 'png', 'jpg', 'jpeg', 'webp'], video: ['mp4', 'webm'] };
const typeOf = (name) => { const e = name.split('.').pop().toLowerCase(); return Object.keys(EXT).find(k => EXT[k].includes(e)) || ''; };
const listMedia = () => { try { return fs.readdirSync(MEDIA_DIR).filter(n => typeOf(n)).map(n => ({ name: n, url: '/media/' + encodeURIComponent(n), type: typeOf(n), size: fs.statSync(path.join(MEDIA_DIR, n)).size })).sort((a, b) => a.name.localeCompare(b.name)); } catch { return []; } };
const isAdminReq = (req) => !ADMIN_PASSWORD || req.get('x-pw') === ADMIN_PASSWORD;

app.get('/api/auth', (req, res) => res.json({ required: !!ADMIN_PASSWORD }));
app.get('/api/media', (req, res) => res.json(listMedia()));
app.post('/api/upload', express.raw({ type: () => true, limit: '30mb' }), (req, res) => {
  if (!isAdminReq(req)) return res.status(401).json({ error: 'Password salah' });
  let name = String(req.query.name || 'file').replace(/[^\w.\- ]+/g, '_').replace(/\s+/g, '_').slice(-80);
  if (!typeOf(name)) return res.status(400).json({ error: 'Format tidak didukung (mp3, wav, ogg, m4a, gif, png, jpg, webp, mp4, webm)' });
  if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ error: 'File kosong' });
  if (fs.existsSync(path.join(MEDIA_DIR, name))) name = Date.now().toString(36) + '_' + name;
  try { fs.writeFileSync(path.join(MEDIA_DIR, name), req.body); } catch (e) { return res.status(500).json({ error: 'Gagal menyimpan: ' + e.message }); }
  io.emit('media', listMedia());
  res.json({ ok: true, name, url: '/media/' + encodeURIComponent(name) });
});

// Impor sound dari link langsung (mp3/wav/ogg/m4a) ke folder media. Hanya admin, link lokal/privat diblokir.
const dns = require('dns').promises, net = require('net');
const privateIp = (ip) => net.isIPv4(ip) ? /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip) : /^(::1|fc|fd|fe80)/i.test(ip);
app.post('/api/import', express.json(), async (req, res) => {
  if (!isAdminReq(req)) return res.status(401).json({ error: 'Password salah' });
  try {
    const u = new URL(String(req.body?.url || '').trim());
    if (!/^https?:$/.test(u.protocol)) throw new Error('Link harus http/https');
    const ips = net.isIP(u.hostname) ? [{ address: u.hostname }] : await dns.lookup(u.hostname, { all: true });
    if (!ips.length || ips.some(i => privateIp(i.address))) throw new Error('Alamat tidak diizinkan');
    let name = String(req.body?.name || decodeURIComponent(u.pathname.split('/').pop() || 'sound.mp3')).replace(/[^\w.\- ]+/g, '_').replace(/\s+/g, '_').slice(-80);
    if (!/\.(mp3|wav|ogg|m4a)$/i.test(name)) name += '.mp3';
    const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0' }, redirect: 'follow', signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error('Server sumber membalas HTTP ' + r.status);
    const ct = String(r.headers.get('content-type') || '');
    if (ct && !/audio|octet-stream|mpeg|ogg|wav/i.test(ct)) throw new Error('Link itu bukan file audio (harus link langsung ke .mp3/.wav)');
    const buf = Buffer.from(await r.arrayBuffer());
    if (!buf.length || buf.length > 10 * 1024 * 1024) throw new Error('File kosong atau lebih dari 10 MB');
    if (fs.existsSync(path.join(MEDIA_DIR, name))) name = Date.now().toString(36) + '_' + name;
    fs.writeFileSync(path.join(MEDIA_DIR, name), buf);
    io.emit('media', listMedia());
    res.json({ ok: true, name, url: '/media/' + encodeURIComponent(name) });
  } catch (e) { res.status(400).json({ error: 'Gagal impor: ' + String(e.message || e).slice(0, 160) }); }
});
app.post('/api/media/delete', express.json(), (req, res) => {
  if (!isAdminReq(req)) return res.status(401).json({ error: 'Password salah' });
  const name = path.basename(String(req.body?.name || ''));
  if (!typeOf(name)) return res.status(400).json({ error: 'Nama tidak valid' });
  try { fs.unlinkSync(path.join(MEDIA_DIR, name)); } catch {}
  io.emit('media', listMedia());
  res.json({ ok: true });
});
app.use(express.static(PUBLIC_DIR));
app.use((err, req, res, next) => res.status(err.status || 500).json({ error: err.type === 'entity.too.large' ? 'File terlalu besar (maks 30 MB)' : String(err.message || err) }));

// ---------- Socket.IO ----------
io.use((sock, next) => { sock.data.admin = !ADMIN_PASSWORD || sock.handshake.auth?.pw === ADMIN_PASSWORD; next(); });

io.on('connection', sock => {
  const adm = (fn) => (...a) => { if (sock.data.admin) fn(...a); };
  sock.emit('auth', { admin: sock.data.admin, required: !!ADMIN_PASSWORD });
  sock.emit('settings', cfg);
  sock.emit('state', publicState());
  sock.emit('timer', timerView());
  sock.emit('poll', pollView());
  sock.emit('giveaway', gwView());
  sock.emit('media', listMedia());
  sock.emit('gifts', Object.values(seenGifts));
  sock.emit('music', musicView());

  sock.on('connectTo', adm(connect));
  sock.on('disconnectLive', adm(() => { wantUser = ''; clearTimeout(retryTimer); dropConn(); resetSession(); pushNow(); }));
  sock.on('saveSettings', adm(s => {
    if (!s || typeof s !== 'object') return;
    const wasShuffle = cfg.music.shuffle;
    cfg = sanitize(merge(cfg, s)); saveSoon();
    if (wasShuffle !== cfg.music.shuffle) { const pl = curPlaylist(); if (pl && music.order.length) { const cur = music.order[music.pos]; music.order = buildOrder(pl.tracks.length, cfg.music.shuffle, cur); music.pos = Math.max(0, music.order.indexOf(cur)); } }
    musicFix(); io.emit('settings', cfg); pushTimer(); pushMusic();
  }));
  sock.on('resetTop', adm(() => { clearObj(gifters); clearObj(likers); clearObj(chatters); pushNow(); }));
  sock.on('resetGoal', adm((t) => {
    const map = { diamond: 'diamonds', likes: 'likeGain', followers: 'followers' };
    const keys = t && map[t] ? [t] : (t === 'all' ? Object.keys(map) : ['diamond']);
    for (const k of keys) goalBase[{ diamond: 'diamonds', likes: 'likes', followers: 'followers' }[k]] = state[map[k]];
    pushNow();
  }));
  sock.on('skipCue', adm(() => io.emit('skip')));

  sock.on('testEvent', adm(t => {
    const o = typeof t === 'string' ? { type: t } : (t || {});
    const w = { user: String(o.user || 'tester').slice(0, 40), nick: String(o.nick || 'Tester').slice(0, 40), avatar: '', badges: Array.isArray(o.badges) ? o.badges.slice(0, 4).map(String) : [] };
    const test = !o.sim; // sim = simulasi penonton: ikut dihitung ke goal/top/poll/giveaway
    if (o.type === 'gift') onGift(w, String(o.gift || 'Rose'), num(o.count) || 1, num(o.diamonds) || 1, '', test);
    else if (o.type === 'follow') onFollow(w, test);
    else if (o.type === 'share') onShare(w, test);
    else if (o.type === 'subscribe') onSubscribe(w);
    else if (o.type === 'join') onJoin(w, test);
    else if (o.type === 'like') onLike(w, num(o.count) || 10, 0, test);
    else if (o.type === 'chat') onChat(w, String(o.text || 'Halo semuanya, ini tes chat!'), test);
  }));
  sock.on('testRow', adm(({ kind, id } = {}) => {
    const w = { user: 'tester', nick: 'Tester', avatar: '' };
    if (kind === 'gift') { const a = cfg.giftActions.find(r => r.id === id); if (a) rowCue('gift', a, { ...w, gift: a.gift === '*' ? 'Rose' : a.gift, count: 1, diamonds: a.minDiamond || 1, giftImg: '' }, cfg.look.bigMin > 0 && (a.minDiamond || 1) >= cfg.look.bigMin ? 'big' : 'normal'); }
    if (kind === 'reminder') { const r = cfg.reminders.find(x => x.id === id); if (r) rowCue('reminder', r, { ...w }); }
    if (kind === 'command') { const c = cfg.commands.find(r => r.id === id); if (c) rowCue('command', c, { ...w, args: 'contoh', text: c.cmd + ' contoh' }); }
  }));

  // Soundboard & roda (dari dashboard)
  sock.on('soundboard', adm(({ sound, volume } = {}) => { if (/^\/(sfx|media|music)\/[\w%.\- ]+$/.test(String(sound))) sendCue({ type: 'soundboard', sound: String(sound), volume: Math.min(1, Math.max(0, Number(volume) || 1)) }); }));
  sock.on('say', adm(text => { const t = cleanFrag(String(text || '')).slice(0, 250); if (t) sendCue({ type: 'say', tts: t }); }));
  sock.on('wheelSpin', adm(() => wheelSpin({ nick: '' })));

  // Musik
  sock.on('musicPlay', adm(({ pl, index } = {}) => musicPlay(pl, index)));
  sock.on('musicPause', adm(() => { music.playing = false; pushMusic(); }));
  sock.on('musicResume', adm(() => { if (curPlaylist() && music.order.length) { music.playing = true; pushMusic(); } else musicPlay(); }));
  sock.on('musicNext', adm(() => musicStep(1, false)));
  sock.on('musicPrev', adm(() => musicStep(-1, false)));
  // dari overlay (tanpa admin): lagu selesai / gagal diputar / ducking saat alert bersuara
  sock.on('musicEnded', ({ seq } = {}) => { if (music.playing && seq === music.seq) { music.errs = 0; musicStep(1, true); } });
  sock.on('musicError', ({ seq } = {}) => { if (music.playing && seq === music.seq) { const pl = curPlaylist(); if (++music.errs > (pl ? pl.tracks.length : 1)) { music.playing = false; pushMusic(); } else musicStep(1, true); } });
  sock.on('duck', on => io.emit('duck', !!on));

  // Poll
  sock.on('pollStart', adm(pollStart));
  sock.on('pollStop', adm(pollStop));
  sock.on('pollHide', adm(() => { clearTimeout(pollTO); poll = { visible: false, active: false, question: '', options: [], total: 0, endsAt: 0 }; clearObj(votes); io.emit('poll', pollView()); }));

  // Giveaway
  sock.on('giveawayStart', adm(() => { gw = { active: true, keyword: cfg.giveaway.keyword || '!ikut', entries: {}, winners: [] }; io.emit('giveaway', gwView()); }));
  sock.on('giveawayStop', adm(() => { gw.active = false; io.emit('giveaway', gwView()); }));
  sock.on('giveawayDraw', adm(from => gwDraw(from)));
  sock.on('giveawayReset', adm(() => { gw = { active: false, keyword: '', entries: {}, winners: [] }; io.emit('giveaway', gwView()); }));

  // Timer
  sock.on('timerStart', adm(sec => { const s = Number(sec) > 0 ? Number(sec) : cfg.timer.start; Object.assign(timer, { started: true, running: true, endsAt: Date.now() + s * 1000, remaining: 0 }); pushTimer(); }));
  sock.on('timerPause', adm(() => { if (!timer.running) return; timer.remaining = Math.max(0, timer.endsAt - Date.now()); timer.running = false; pushTimer(); }));
  sock.on('timerResume', adm(() => { if (!timer.started || timer.running) return; timer.endsAt = Date.now() + timer.remaining; timer.running = true; pushTimer(); }));
  sock.on('timerAdd', adm(sec => timerAdd(Number(sec) || 0)));
  sock.on('timerReset', adm(() => { Object.assign(timer, { started: false, running: false, endsAt: 0, remaining: 0 }); pushTimer(); }));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, process.env.HOST || '0.0.0.0', () => {
  console.log(`Dashboard : http://localhost:${PORT}${ADMIN_PASSWORD ? '  (dilindungi ADMIN_PASSWORD)' : ''}`);
  console.log(`Overlay   : http://localhost:${PORT}/overlay.html  (pakai di OBS / LIVE Studio)`);
  const auto = process.env.TIKTOK_USER || (cfg.connection.autoStart && (cfg.connection.myUser || cfg.connection.lastUser));
  if (auto) setTimeout(() => connect(auto), 1500);
});
