// Logika dashboard RYZFinity
const { $, esc, fmtNum } = RY;
let pw = localStorage.getItem('ry_pw') || '';
const s = io({ auth: { pw } });
let cfg = null, draft = null, st = { goal: {} }, media = [], tm = null, tmOff = 0, gw = { count: 0, winners: [], active: false }, pl = null, lastEdit = 0, saveT = null;
let ui = {}; try { ui = JSON.parse(localStorage.getItem('ry_ui') || '{}'); } catch {}
const UIDEF = { pq: 'Pilih salah satu!', po: 'Pilihan A\nPilihan B', pd: 60 };
const uiv = (k, d) => ui[k] ?? d ?? UIDEF[k] ?? '';

const ICONS = {
  live: '<circle cx="12" cy="12" r="2.5"/><path d="M7.5 7.5a6.5 6.5 0 0 0 0 9M16.5 7.5a6.5 6.5 0 0 1 0 9M4.5 4.5a10.5 10.5 0 0 0 0 15M19.5 4.5a10.5 10.5 0 0 1 0 15"/>',
  voice: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/>',
  events: '<path d="M6 16v-5a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',
  look: '<path d="M12 3l1.8 4.6L18.5 9l-4.7 1.4L12 15l-1.8-4.6L5.5 9l4.7-1.4z"/><path d="M18 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  sounds: '<path d="M4 10v4h3l5 4V6L7 10z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  gifts: '<rect x="3.5" y="9" width="17" height="11" rx="1.5"/><path d="M3.5 13h17M12 9v11M12 9C10 9 7.5 8 7.5 6.5S9 4 10.5 5 12 9 12 9zM12 9c2 0 4.5-1 4.5-2.5S15 4 13.5 5 12 9 12 9z"/>',
  cmds: '<rect x="2.5" y="4" width="19" height="16" rx="3"/><path d="M6.5 9l3 3-3 3M12 15h5"/>',
  interact: '<path d="M4 5h16v10H9l-5 4z"/><path d="M8 9h8M8 12h5"/>',
  music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  goals: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
  overlays: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  board: '<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
  wheel: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4"/>',
  media: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
};
const TABS = [['live', 'Live', '#22d3ee'], ['voice', 'Suara & TTS', '#a78bfa'], ['events', 'Alert & Sound', '#fbbf24'], ['look', 'Tampilan', '#ff4d8d'], ['sounds', 'Sound Gift', '#34d399'], ['board', 'Soundboard', '#f59e0b'], ['wheel', 'Roda Putar', '#ec4899'], ['gifts', 'Gift Action', '#fb7185'], ['cmds', 'Command Chat', '#60a5fa'], ['interact', 'Interaksi', '#f472b6'], ['music', 'Musik', '#c084fc'], ['goals', 'Goal', '#fb923c'], ['overlays', 'Overlay', '#818cf8'], ['media', 'Media', '#2dd4bf']];
const ROW_GIFT = { enabled: true, gift: '*', minDiamond: 0, alertText: '{nick} kirim {gift}', alertSub: '', ttsText: '', sound: '', media: '', duration: 6, volume: 1, keepDefault: false };
const ROW_CMD = { enabled: true, cmd: '!info', alertText: '', alertSub: '', ttsText: '', sound: '', media: '', duration: 6, volume: 1, cooldown: 10 };

let sfxList = [], musicLib = [], seen = [], mv = { playing: false, plName: '', tracks: [], cur: 0 };
const get = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
const set = (o, p, v) => { const ks = p.split('.'), last = ks.pop(); ks.reduce((a, k) => a[k], o)[last] = v; };
const toast = (t) => { const e = $('toast'); e.textContent = t; e.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => e.style.display = 'none', 2600); };

// ---------- Pembuat form ----------
const F = {
  chk: (p, l) => `<label class="chk"><input type="checkbox" data-p="${p}" data-t="b"><span>${l}</span></label>`,
  txt: (p, l, ph = '', w = '') => `<label class="fld ${w}"><span>${l}</span><input data-p="${p}" data-t="s" placeholder="${esc(ph)}"></label>`,
  num: (p, l, min = 0, max = 100000, step = 1) => `<label class="fld"><span>${l}</span><input type="number" data-p="${p}" data-t="n" min="${min}" max="${max}" step="${step}"></label>`,
  area: (p, l, ph = '') => `<label class="fld wide"><span>${l}</span><textarea data-p="${p}" data-t="s" placeholder="${esc(ph)}"></textarea></label>`,
  sel: (p, l, opts) => `<label class="fld"><span>${l}</span><select data-p="${p}" data-t="s">${opts.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join('')}</select></label>`,
  rng: (p, l, min, max, step) => `<label class="fld"><span>${l}: <b data-o="${p}"></b></span><input type="range" data-p="${p}" data-t="n" min="${min}" max="${max}" step="${step}"></label>`,
  snd: (p, l = 'Suara (opsional)') => { const au = media.filter(m => m.type === 'audio');
    return `<label class="fld"><span>${l}</span><select data-p="${p}" data-t="s"><option value="">(tanpa suara)</option>${sfxList.length ? `<optgroup label="Pustaka SFX">${sfxList.map(x => `<option value="/sfx/${x.file}">${esc(x.label)}</option>`).join('')}</optgroup>` : ''}${au.length ? `<optgroup label="Upload saya">${au.map(m => `<option value="${esc(m.url)}">${esc(m.name)}</option>`).join('')}</optgroup>` : ''}</select></label>`; },
  med: (p, l = 'Gambar / video (opsional)') => F.sel(p, l, [['', '(tanpa media)'], ...media.filter(m => m.type !== 'audio').map(m => [m.url, m.name])]),
};

// ---------- Tab Suara ----------
const LANGS = [['id-ID', 'Indonesia'], ['en-US', 'Inggris (US)'], ['en-GB', 'Inggris (UK)'], ['ms-MY', 'Melayu'], ['ar-SA', 'Arab'], ['ja-JP', 'Jepang'], ['ko-KR', 'Korea'], ['es-ES', 'Spanyol'], ['hi-IN', 'Hindi'], ['th-TH', 'Thailand'], ['vi-VN', 'Vietnam'], ['fil-PH', 'Filipino']];
function voiceTab() {
  const vs = window.speechSynthesis ? speechSynthesis.getVoices() : [];
  const lang = draft.voice.lang.split('-')[0];
  vs.sort((a, b) => (b.lang.startsWith(lang) - a.lang.startsWith(lang)) || a.name.localeCompare(b.name));
  return `<div class="card"><h2>Suara (TTS)</h2><p class="hint">Dipakai untuk membacakan gift, follow, chat, dll. Teks yang dibacakan diatur di tab Alert &amp; Sound.</p>
  <div class="grid">
    ${F.sel('voice.engine', 'Mesin suara', [['browser', 'Suara perangkat (bawaan browser)'], ['google', 'Suara Google (lewat server)']])}
    ${F.sel('voice.lang', 'Bahasa', LANGS)}
    ${F.sel('voice.name', 'Pilih suara (khusus mesin perangkat)', [['', 'Otomatis sesuai bahasa'], ...vs.map(v => [v.name, `${v.name} (${v.lang})`])])}
    ${F.num('voice.maxLen', 'Maks. panjang komentar yang dibacakan (huruf)', 20, 300)}
    ${F.rng('voice.rate', 'Kecepatan', 0.5, 2, 0.1)}
    ${F.rng('voice.pitch', 'Nada (mesin perangkat)', 0, 2, 0.1)}
    ${F.rng('voice.volume', 'Volume', 0, 1, 0.05)}
  </div>
  <div class="row"><button class="p" data-act="voiceLocal">Tes suara di dashboard</button><button data-act="testEvent" data-type="gift">Tes lewat overlay</button><button data-act="voiceStop">Stop</button></div>
  <p class="hint">Daftar suara di atas diambil dari browser yang membuka dashboard ini. Overlay di OBS / LIVE Studio bisa punya daftar suara berbeda; kalau suaranya tidak keluar atau beda, pakai <b>Suara Google</b> (butuh internet di server) supaya konsisten. Jangan lupa aktifkan "Control audio via OBS".</p></div>
  <div class="card"><h2>Filter</h2><div class="grid">${F.area('filter.blacklist', 'Kata terlarang (pisahkan dengan koma). Kalau ada, kalimat tidak dibacakan.', 'contoh: judi, slot, kasar')}${F.chk('filter.skipLinks', 'Hapus link dari teks yang dibacakan')}</div><p class="hint">Emoji otomatis dibuang dari teks yang dibacakan.</p></div>`;
}

// ---------- Tab Alert & Sound ----------
const EVT = [
  { k: 'gift', t: 'Gift', vars: '{nick} {user} {gift} {count} {diamonds}', extra: F.num('events.gift.minDiamond', 'Min. diamond untuk alert default') },
  { k: 'follow', t: 'Follow', vars: '{nick} {user}' },
  { k: 'share', t: 'Share', vars: '{nick} {user}' },
  { k: 'subscribe', t: 'Subscribe', vars: '{nick} {user}' },
  { k: 'join', t: 'Penonton masuk (sambutan)', vars: '{nick} {user}', extra: F.num('events.join.gap', 'Jeda antar sambutan (detik)') },
  { k: 'like', t: 'Milestone like', vars: '{total}', extra: F.num('events.like.every', 'Setiap kelipatan berapa like', 10) },
];
function eventsTab() {
  const cards = EVT.map(e => { const P = `events.${e.k}.`; return `<div class="card"><h2>${e.t}<button class="sm sp" data-act="testEvent" data-type="${e.k}">Tes</button></h2>
    <p class="hint">Variabel: <code>${e.vars}</code></p>
    <div class="row" style="margin:0 0 10px;gap:18px">${F.chk(P + 'alert', 'Tampilkan alert')}${F.chk(P + 'tts', 'Bacakan (TTS)')}</div>
    <div class="grid">${F.txt(P + 'alertText', 'Teks alert')}${F.txt(P + 'alertSub', 'Teks kecil')}${F.txt(P + 'ttsText', 'Kalimat yang dibacakan')}${F.snd(P + 'sound')}${F.num(P + 'duration', 'Lama tampil (detik)', 1, 60)}${e.extra || ''}</div></div>`; }).join('');
  const C = 'events.chat.';
  return `<p class="hint">Atur apa yang muncul dan terdengar untuk tiap jenis event. Perubahan tersimpan otomatis.</p>${cards}
  <div class="card"><h2>Bacakan komentar chat</h2><p class="hint">Variabel: <code>{nick} {text}</code>. Kalau "awalan" diisi (misal <code>!say</code>), hanya komentar yang diawali itu yang dibacakan.</p>
    <div class="row" style="margin:0 0 10px;gap:18px">${F.chk(C + 'tts', 'Bacakan komentar (TTS)')}${F.chk(C + 'skipCommands', 'Jangan bacakan komentar berawalan !')}</div>
    <div class="grid">${F.txt(C + 'ttsText', 'Kalimat yang dibacakan')}${F.txt(C + 'prefix', 'Awalan wajib (kosong = semua)')}${F.num(C + 'minLen', 'Min. panjang komentar', 0, 100)}${F.num(C + 'cooldown', 'Jeda per penonton (detik)', 0, 600)}${F.sel(C + 'only', 'Hanya bacakan komentar dari', [['all', 'Semua penonton'], ['follower', 'Follower (termasuk subscriber/mod)'], ['subscriber', 'Subscriber'], ['moderator', 'Moderator'], ['gifter', 'Yang pernah kirim gift']])}</div>
    <div class="row"><button class="sm" data-act="testEvent" data-type="chat">Tes</button></div></div>`;
}

// ---------- Tab Gift Action & Command ----------
function rowFields(list, i, kind) {
  const P = `${list}.${i}.`;
  return `${kind === 'gift' ? `${F.txt(P + 'gift', 'Nama gift (* = semua gift)', 'Rose')}${F.num(P + 'minDiamond', 'Min. total diamond')}` : `${F.txt(P + 'cmd', 'Command', '!sosmed')}${F.num(P + 'cooldown', 'Jeda (detik)', 0, 3600)}`}
  ${F.txt(P + 'alertText', 'Teks alert')}${F.txt(P + 'alertSub', 'Teks kecil')}${F.txt(P + 'ttsText', 'Kalimat yang dibacakan')}${F.snd(P + 'sound')}${F.med(P + 'media')}${F.num(P + 'duration', 'Lama tampil (detik)', 1, 60)}${F.rng(P + 'volume', 'Volume suara/video', 0, 1, 0.05)}`;
}
function giftsTab() {
  const rows = draft.giftActions.map((a, i) => `<div class="item ${a.enabled ? '' : 'off'}"><div class="row" style="margin:0 0 10px;gap:14px">${F.chk(`giftActions.${i}.enabled`, 'Aktif')}${F.chk(`giftActions.${i}.keepDefault`, 'Tetap tampilkan alert gift default juga')}<span style="margin-left:auto"></span><button class="sm" data-act="testRow" data-kind="gift" data-id="${a.id}">Tes</button><button class="sm d" data-act="delRow" data-list="giftActions" data-i="${i}">Hapus</button></div><div class="grid">${rowFields('giftActions', i, 'gift')}</div></div>`).join('');
  return `<div class="card"><h2>Gift Action<button class="p sm sp" data-act="addRow" data-list="giftActions">+ Tambah aksi</button></h2>
  <p class="hint">Atur reaksi khusus untuk gift tertentu: suara meme, video, teks, atau kalimat TTS sendiri. Variabel: <code>{nick} {gift} {count} {diamonds}</code>. Aturan yang namanya cocok dipakai duluan, lalu aturan "*". Kalau ada beberapa aturan untuk gift yang sama, yang min. diamond-nya paling tinggi dan masih terpenuhi yang dipakai. Upload file dulu di tab Media.</p>${rows || '<p class="hint">Belum ada aksi. Klik "+ Tambah aksi".</p>'}</div>`;
}
function cmdsTab() {
  const rows = draft.commands.map((a, i) => `<div class="item ${a.enabled ? '' : 'off'}"><div class="row" style="margin:0 0 10px;gap:14px">${F.chk(`commands.${i}.enabled`, 'Aktif')}<span style="margin-left:auto"></span><button class="sm" data-act="testRow" data-kind="command" data-id="${a.id}">Tes</button><button class="sm d" data-act="delRow" data-list="commands" data-i="${i}">Hapus</button></div><div class="grid">${rowFields('commands', i, 'cmd')}</div></div>`).join('');
  return `<div class="card"><h2>Command Chat<button class="p sm sp" data-act="addRow" data-list="commands">+ Tambah command</button></h2>
  <p class="hint">Saat penonton mengetik command di chat (misal <code>!sosmed</code>), overlay menampilkan balasan, memutar suara, atau membacakan teks. Variabel: <code>{nick}</code> (pengetik) dan <code>{args}</code> (teks setelah command). Voting memakai angka (1, 2, 3...) dan giveaway memakai kata kunci, diatur di tab Interaksi.</p>${rows || '<p class="hint">Belum ada command. Klik "+ Tambah command".</p>'}</div>`;
}

// ---------- Tab Interaksi ----------
function interactTab0() {
  return `<div class="card"><h2>Voting (poll) lewat chat</h2><p class="hint">Penonton memilih dengan mengetik angka (1, 2, 3...). Tampilkan lewat overlay poll.html.</p>
    <div class="grid"><label class="fld wide"><span>Pertanyaan</span><input data-u="pq" value="${esc(uiv('pq', 'Pilih salah satu!'))}"></label>
    <label class="fld wide"><span>Pilihan (satu per baris, 2 sampai 9)</span><textarea data-u="po">${esc(uiv('po', 'Pilihan A\nPilihan B'))}</textarea></label>
    <label class="fld"><span>Durasi (detik, 0 = manual)</span><input type="number" min="0" data-u="pd" value="${esc(uiv('pd', 60))}"></label>${F.chk('poll.announce', 'Bacakan pemenang saat voting selesai')}</div>
    <div class="row"><button class="p" data-act="pollStart">Mulai voting</button><button data-act="pollStop">Hentikan</button><button data-act="pollHide">Sembunyikan</button><button class="sm" data-act="simPoll" title="Kirim 10 suara acak untuk uji coba">Simulasi 10 suara</button></div></div>
  <div class="card"><h2>Giveaway</h2><p class="hint">Mulai kumpulkan peserta, penonton ketik kata kunci di chat, lalu undi. Pemenang tidak akan terpilih dua kali. Tampilkan lewat overlay giveaway.html. Variabel kalimat: <code>{nick}</code></p>
    <div class="grid">${F.txt('giveaway.keyword', 'Kata kunci di chat', '!ikut')}${F.txt('giveaway.announceText', 'Kalimat pengumuman pemenang (dibacakan)')}</div>
    <div class="row"><button class="p" data-act="gwStart">Mulai kumpulkan peserta</button><button data-act="gwStop">Berhenti terima peserta</button><button data-act="gwDraw" data-from="entries">Undi dari peserta</button><button data-act="gwDraw" data-from="gifters">Undi dari yang sudah kirim gift</button><button class="d" data-act="gwReset">Reset</button><button class="sm" data-act="simGw" title="Tambah 10 peserta palsu untuk uji coba">Simulasi 10 peserta</button></div>
    <p class="hint" id="gwInfo" style="margin-top:10px"></p></div>
  <div class="card"><h2>Timer hitung mundur</h2><p class="hint">Waktu bisa bertambah otomatis dari gift, follow, dan share (isi 0 untuk mematikan). Tampilkan lewat overlay timer.html.</p>
    <div class="grid">${F.txt('timer.title', 'Judul timer')}${F.num('timer.start', 'Durasi awal (detik)', 1, 86400)}${F.num('timer.perDiamond', 'Tambah detik per 1 diamond', 0, 3600, 0.1)}${F.num('timer.perFollow', 'Tambah detik per follow', 0, 3600)}${F.num('timer.perShare', 'Tambah detik per share', 0, 3600)}${F.num('timer.max', 'Batas maksimal sisa waktu (detik, 0 = bebas)', 0, 86400)}</div>
    <div class="row"><span class="big" id="tmNow">--:--</span><button class="p" data-act="timerStart">Mulai</button><button data-act="timerPause">Jeda</button><button data-act="timerResume">Lanjut</button><button data-act="timerAdd" data-n="30">+30 dtk</button><button data-act="timerAdd" data-n="-30">-30 dtk</button><button class="d" data-act="timerReset">Reset</button></div></div>`;
}

// ---------- Tab Goal ----------
function goalsTab() {
  const G = [['diamond', 'Goal diamond'], ['likes', 'Goal like (dihitung sejak tersambung)'], ['followers', 'Goal follower baru']];
  return G.map(([k, t]) => { const v = st.goal?.[k] || 0, tg = draft.goals[k].target || 1;
    return `<div class="card"><h2>${t}<button class="sm d sp" data-act="resetGoal" data-t="${k}">Reset progres</button></h2><div class="grid">${F.txt(`goals.${k}.title`, 'Judul')}${F.num(`goals.${k}.target`, 'Target', 1, 100000000)}</div>
    <div class="row"><b data-gv="${k}">${fmtNum(v)} / ${fmtNum(tg)}</b></div><div class="bar"><i data-gb="${k}" style="width:${Math.min(100, v / tg * 100)}%"></i></div></div>`; }).join('')
    + `<div class="row"><button class="d" data-act="resetGoal" data-t="all">Reset semua goal</button></div><p class="hint">Pasang di OBS: goal.html (diamond), goal.html?type=likes, goal.html?type=followers, atau gabungan goal.html?type=diamond,likes,followers</p>`;
}

// ---------- Tab Overlay ----------
const OV = [
  ['Alert + suara', 'alerts.html', 'Wajib dipasang kalau mau ada alert, suara gift, dan TTS. Opsi: ?time=5 (paksa lama tampil)'],
  ['Komentar / chat', 'chat.html', 'Opsi: ?max=8&life=30&events=1&join=1'],
  ['Goal', 'goal.html', 'Opsi: ?type=diamond | likes | followers | diamond,likes,followers'],
  ['Top gifter / liker / komentar', 'top.html', 'Opsi: ?type=gifters | likers | chatters &n=5'],
  ['Statistik live', 'stats.html', 'Opsi: ?show=viewers,likes,followers,diamonds,shares,gifts'],
  ['Roda putar', 'wheel.html', 'Roda hadiah, diputar lewat gift atau tombol di tab Roda Putar'], ['Timer', 'timer.html', ''], ['Voting (poll)', 'poll.html', ''], ['Giveaway', 'giveaway.html', ''],
  ['Semua jadi satu', 'overlay.html', 'Pilih widget: ?w=alerts,goal,poll,giveaway,timer,top,stats,chat,wheel'],
];
function overlaysTab() {
  return `<div class="card"><h2>URL Overlay</h2><p class="hint">Pasang tiap URL sebagai Browser Source di OBS / TikTok LIVE Studio (1920x1080, latar sudah transparan). Semua widget bisa diatur dengan <code>?pos=tl|tr|bl|br|tc|bc|cl|cr|c</code> dan <code>?scale=1.5</code>. Gabungkan dengan tanda &amp;, misalnya <code>chat.html?pos=br&amp;scale=1.2</code>.</p>
  ${OV.map(([n, f, h]) => `<div class="ovr"><b>${n}</b><code>${location.origin}/${f}</code><button class="sm" data-act="copy" data-u="${location.origin}/${f}">Salin</button>${h ? `<div class="h">${h}</div>` : ''}</div>`).join('')}</div>`;
}

// ---------- Tab Media ----------
const fsz = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.ceil(n / 1024) + ' KB';
function mediaTab() {
  return `<div class="card"><h2>Upload file</h2><p class="hint">Suara: mp3, wav, ogg, m4a. Gambar: gif, png, jpg, webp. Video: mp4, webm. Maks. 30 MB per file. File tersimpan di folder public/media pada server.</p>
  <div class="drop" id="drop">Seret file ke sini atau <button data-act="pick" class="sm">pilih file</button><input type="file" id="file" multiple accept=".mp3,.wav,.ogg,.m4a,.gif,.png,.jpg,.jpeg,.webp,.mp4,.webm" hidden></div></div>
  <div class="card"><h2>File tersimpan (${media.length})</h2>${media.map(m => `<div class="media"><div class="n"><b>${esc(m.name)}</b><br><span class="hint">${m.type} - ${fsz(m.size)}</span></div>${m.type === 'audio' ? `<audio controls preload="none" src="${m.url}"></audio>` : m.type === 'image' ? `<img src="${m.url}" alt="">` : `<video muted controls preload="metadata" src="${m.url}"></video>`}<button class="sm" data-act="copy" data-u="${m.url}">Salin URL</button><button class="sm d" data-act="delMedia" data-name="${esc(m.name)}">Hapus</button></div>`).join('') || '<p class="hint">Belum ada file.</p>'}</div>`;
}


// ---------- Tab Tampilan (tema & gift besar) ----------
const THEMES = [['klasik', 'Klasik'], ['neon', 'Neon'], ['kaca', 'Kaca'], ['emas', 'Emas'], ['pixel', 'Pixel'], ['minimal', 'Minimal'], ['gradient', 'Gradien'], ['sakura', 'Sakura'], ['cyber', 'Cyber'], ['royal', 'Royal'], ['retro', 'Retro'], ['comic', 'Komik'], ['mint', 'Mint']];
const FX = [['none', 'Tanpa efek'], ['glow', 'Menyala'], ['confetti', 'Confetti'], ['shake', 'Getar']];
const ICON = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><circle cx="48" cy="48" r="44" fill="#ff4d8d"/><path d="M48 70 26 48a13 13 0 0 1 22-14 13 13 0 0 1 22 14z" fill="#fff"/></svg>');
const fillT = (t, v) => String(t || '').replace(/\{(\w+)\}/g, (_, k) => v[k] ?? '');
const alHtml = (theme, effect, title, sub) => `<div class="al th-${theme}${effect && effect !== 'none' ? ' fx-' + effect : ''}"><div class="m"></div><div class="row"><img class="i" src="${ICON}" alt=""><div><span class="t">${esc(title)}</span><small class="s">${esc(sub)}</small></div></div></div>`;
function lookTab() {
  const pick = key => THEMES.map(([k, t]) => `<button class="tp ${get(draft, key) === k ? 'sel' : ''}" data-act="pickTheme" data-key="${key}" data-v="${k}"><div class="pvbg"><div style="zoom:.42">${alHtml(k, 'none', 'Andi kirim Rose ×5', '5 diamond')}</div></div><b>${t}</b></button>`).join('');
  return packsCard() + `<div class="card"><h2>Preview<span class="sp"></span><button class="sm" data-act="replay">Putar ulang</button></h2>
  <p class="hint">Begini tampilan alert gift di layar. Gift biasa dan gift besar bisa dibuat beda tema, ukuran, efek, dan suara. Perubahan tersimpan otomatis.</p>
  <div class="pvs"><div><div class="hint">Gift biasa (di bawah <b data-bigmin></b> diamond)</div><div class="pvbg pvbox" id="pvNormal"></div></div>
  <div><div class="hint">Gift besar (mulai <b data-bigmin></b> diamond)</div><div class="pvbg pvbox" id="pvBig"></div></div></div>
  <div class="row"><button data-act="testSmall">Tes di overlay: gift biasa</button><button class="p" data-act="testBig">Tes di overlay: gift besar</button></div></div>
  <div class="card"><h2>Gift besar</h2><p class="hint">Gift dianggap besar kalau total diamond-nya (jumlah × harga) mencapai batas di bawah. Kosongkan teks atau suara supaya memakai pengaturan gift biasa dari tab Alert &amp; Sound. Variabel: <code>{nick} {gift} {count} {diamonds}</code></p>
  <div class="grid">${F.num('look.bigMin', 'Besar mulai (total diamond, 0 = nonaktif)', 0, 100000000)}${F.sel('look.bigEffect', 'Efek gift besar', FX)}${F.rng('look.bigScale', 'Ukuran', 1, 2.5, 0.1)}${F.num('look.bigDuration', 'Lama tampil (detik)', 1, 60)}${F.snd('look.bigSound', 'Suara gift besar')}${F.txt('look.bigAlertText', 'Teks alert')}${F.txt('look.bigAlertSub', 'Teks kecil')}${F.txt('look.bigTtsText', 'Kalimat yang dibacakan')}</div></div>
  <div class="card"><h2>Efek gift biasa</h2><div class="grid">${F.sel('look.effect', 'Efek', FX)}</div></div>
  <div class="card"><h2>Tema gift biasa</h2><p class="hint">Dipakai juga untuk follow, share, subscribe, dan alert lainnya.</p><div class="themes">${pick('look.theme')}</div></div>
  <div class="card"><h2>Tema gift besar</h2><div class="themes">${pick('look.bigTheme')}</div></div>`;
}
function refreshPreviews() {
  const n = $('pvNormal'), b = $('pvBig'); if (!n || !b || !draft) return;
  const L = draft.look, E = draft.events.gift, vn = { nick: 'Andi', gift: 'Rose', count: 5, diamonds: 5 }, vb = { nick: 'Budi', gift: 'Lion', count: 1, diamonds: Math.max(L.bigMin, 100) };
  const put = (el, theme, fx, title, sub, z) => { el.innerHTML = `<div style="zoom:${z}">${alHtml(theme, fx, title, sub)}</div>`; if (fx === 'confetti') RY.burst(el.firstChild.firstChild); };
  put(n, L.theme, L.effect, fillT(E.alertText, vn), fillT(E.alertSub, vn), 0.6);
  put(b, L.bigTheme, L.bigEffect, fillT(L.bigAlertText || E.alertText, vb), fillT(L.bigAlertText ? L.bigAlertSub : E.alertSub, vb), 0.6 * L.bigScale);
  document.querySelectorAll('[data-bigmin]').forEach(e => e.textContent = L.bigMin);
}


// ---------- Pengingat otomatis ----------
const ROW_SND = { enabled: true, gift: '', minDiamond: 0, sound: '', volume: 1 };
const ROW_REM = { enabled: true, every: 5, alertText: 'Teks pengingat', alertSub: '', ttsText: '', sound: '', duration: 6 };
function interactTab() {
  const rows = draft.reminders.map((r, i) => `<div class="item ${r.enabled ? '' : 'off'}"><div class="row" style="margin:0 0 12px;gap:14px">${F.chk(`reminders.${i}.enabled`, 'Aktif')}<span class="sp"></span><button class="sm" data-act="testRow" data-kind="reminder" data-id="${r.id}">Tes</button><button class="sm d" data-act="delRow" data-list="reminders" data-i="${i}">Hapus</button></div>
    <div class="grid">${F.num(`reminders.${i}.every`, 'Ulangi tiap (menit)', 1, 240)}${F.txt(`reminders.${i}.alertText`, 'Teks alert')}${F.txt(`reminders.${i}.alertSub`, 'Teks kecil')}${F.txt(`reminders.${i}.ttsText`, 'Kalimat yang dibacakan')}${F.snd(`reminders.${i}.sound`)}${F.num(`reminders.${i}.duration`, 'Lama tampil (detik)', 1, 60)}</div></div>`).join('');
  return interactTab0() + `<div class="card"><h2>Pengingat otomatis<button class="p sm sp" data-act="addRow" data-list="reminders">+ Tambah</button></h2>
  <p class="hint">Muncul dan dibacakan berkala selama live tersambung. Cocok untuk mengajak penonton tap-tap layar (supaya like naik), follow, atau share. Dua contoh di bawah belum aktif, nyalakan kalau mau.</p>${rows || '<p class="hint">Belum ada pengingat.</p>'}</div>`;
}

// ---------- Tab Sound Gift ----------
const COMMON_GIFTS = ['Rose', 'TikTok', 'Finger Heart', 'Heart Me', 'GG', 'Doughnut', 'Hand Hearts', 'Perfume', 'Corgi', 'Money Gun', 'Swan', 'Galaxy', 'Lion', 'Universe'];
const PRESET = [['Rose', 'ding'], ['TikTok', 'pop'], ['Finger Heart', 'sparkle'], ['Heart Me', 'notif'], ['GG', 'success'], ['Doughnut', 'coin'], ['Hand Hearts', 'levelup'], ['Perfume', 'bubble'], ['Corgi', 'boing'], ['Money Gun', 'kaching'], ['Swan', 'tada'], ['Galaxy', 'fanfare'], ['Lion', 'airhorn'], ['Universe', 'bassdrop']];
const PLAY = '&#9654;&#xFE0E;';
function soundsTab() {
  const cats = ['Semua', ...new Set(sfxList.map(x => x.cat))], cat = uiv('sfxCat', 'Semua');
  const items = sfxList.filter(x => cat === 'Semua' || x.cat === cat);
  const used = new Set(draft.giftSounds.map(r => r.gift.trim().toLowerCase()));
  const rows = draft.giftSounds.map((r, i) => {
    const g = seen.find(x => x.name.toLowerCase() === r.gift.trim().toLowerCase());
    return `<div class="srow ${r.enabled ? '' : 'off'}"><div class="gi">${g && g.img ? `<img src="${esc(g.img)}" referrerpolicy="no-referrer" alt="">` : '<span class="gph"></span>'}</div>${F.chk(`giftSounds.${i}.enabled`, '')}
      <label class="fld"><span>Gift</span><input data-p="giftSounds.${i}.gift" data-t="s" list="giftNames" placeholder="nama gift (kosong = semua)"></label>
      ${F.num(`giftSounds.${i}.minDiamond`, 'Min. diamond', 0, 100000000)}${F.snd(`giftSounds.${i}.sound`, 'Sound')}${F.rng(`giftSounds.${i}.volume`, 'Volume', 0, 1, 0.05)}
      <div class="act"><button class="sm" data-act="playSnd" data-i="${i}">Dengar</button><button class="sm" data-act="testSnd" data-i="${i}">Tes</button><button class="sm d" data-act="delRow" data-list="giftSounds" data-i="${i}">Hapus</button></div></div>`;
  }).join('');
  const chips = seen.filter(g => !used.has(g.name.toLowerCase())).slice(0, 40).map(g => `<button class="chip" data-act="addSoundFor" data-gift="${esc(g.name)}">${g.img ? `<img src="${esc(g.img)}" referrerpolicy="no-referrer" alt="">` : ''}${esc(g.name)}${g.diamonds ? ` <small>${g.diamonds}</small>` : ''}</button>`).join('');
  return `<div class="card"><h2>Sound per gift<span class="sp"></span><button class="sm" data-act="fillPreset">Isi contoh (14 gift)</button><button class="p sm" data-act="addRow" data-list="giftSounds">+ Tambah gift</button></h2>
  <p class="hint">Pilih gift, pilih bunyinya. Bebas berapa pun gift (tidak dibatasi 5). Suara diputar bersamaan dengan alert gift. Gift dengan nama sama dipilih duluan, lalu baris kosong (semua gift). Min. diamond membuat gift mahal bunyinya beda dari gift murah.</p>
  ${rows || '<p class="hint">Belum ada. Klik "+ Tambah gift" atau "Isi contoh".</p>'}
  ${chips ? `<div class="hint" style="margin-top:14px"><b>Gift yang pernah masuk di live kamu</b> (klik untuk menambahkan)</div><div class="chips">${chips}</div><div class="row" style="margin-top:0"><button class="sm" data-act="addAllSeen">Tambahkan semuanya</button></div>` : '<p class="hint" style="margin-top:14px">Nama gift yang masuk saat live akan muncul di sini supaya tinggal klik.</p>'}</div>
  <div class="card"><h2>Pustaka SFX<span class="sp"></span><button class="sm" data-act="pickAudio">Upload sound sendiri</button></h2>
  <p class="hint">${sfxList.length} efek suara bawaan (buatan sendiri lewat sintesis, bebas dipakai; kategori "Viral & lucu" isinya bunyi bergaya meme seperti boom, dun dun dun, bonk, bebek, kucing, womp womp). Klik tombol putar untuk mendengar. Untuk sound meme asli yang lagi viral, tempel link langsung file mp3 di bawah ini atau upload file sendiri, hasilnya muncul di grup "Upload saya" pada pilihan sound.</p>
  <div class="row" style="margin:0 0 14px"><input id="impUrl" placeholder="tempel link langsung .mp3 (contoh: https://.../sound.mp3)" style="flex:1;min-width:220px"><button class="p sm" data-act="importUrl">Impor dari link</button></div>
  <div class="chips">${cats.map(c => `<button class="chip ${c === cat ? 'sel' : ''}" data-act="sfxCat" data-v="${esc(c)}">${esc(c)}</button>`).join('')}</div>
  <div class="sfxgrid">${items.map(x => `<div class="sfx"><button class="play" data-act="playSfx" data-u="/sfx/${x.file}" aria-label="Putar ${esc(x.label)}">${PLAY}</button><span>${esc(x.label)}</span><small>${x.sec}s</small></div>`).join('')}</div></div>`;
}


// ---------- Tab Soundboard ----------
function boardItems() {
  const au = media.filter(m => m.type === 'audio').map(m => ({ u: m.url, label: m.name.replace(/\.[^.]+$/, '').replace(/^[a-z0-9]{6,8}_/i, '').replace(/_/g, ' '), cat: 'Upload saya' }));
  return [...sfxList.map(x => ({ u: '/sfx/' + x.file, label: x.label, cat: x.cat })), ...au];
}
function boardTab() {
  const all = boardItems(), fav = (ui.fav || []).filter(u => all.some(x => x.u === u));
  const cats = ['Favorit', 'Semua', ...new Set(all.map(x => x.cat))], cat = uiv('boardCat', 'Semua');
  const items = cat === 'Favorit' ? fav.map(u => all.find(x => x.u === u)) : all.filter(x => cat === 'Semua' || x.cat === cat);
  const btn = x => `<div class="sbx"><button class="sb" data-act="sbPlay" data-u="${esc(x.u)}">${fav.includes(x.u) ? '<i class="k">' + (fav.indexOf(x.u) + 1 <= 9 ? fav.indexOf(x.u) + 1 : '') + '</i>' : ''}${esc(x.label)}</button><button class="sm st ${fav.includes(x.u) ? 'on' : ''}" data-act="sbFav" data-u="${esc(x.u)}" title="Favorit (tombol keyboard 1-9)">&#9733;</button></div>`;
  return `<div class="card"><h2>Soundboard live<span class="sp"></span><button class="d sm" data-act="sbStop">Stop semua suara</button></h2>
  <p class="hint">Klik tombol untuk memutar suara ke live lewat overlay alerts.html (pastikan sudah terpasang). Tandai bintang untuk favorit, lalu tekan angka 1-9 di keyboard sebagai tombol cepat saat live.</p>
  <div class="chips">${cats.map(c => `<button class="chip ${c === cat ? 'sel' : ''}" data-act="boardCat" data-v="${esc(c)}">${esc(c)}${c === 'Favorit' ? ' (' + fav.length + ')' : ''}</button>`).join('')}</div>
  <div class="sbgrid">${items.map(btn).join('') || '<p class="hint">Belum ada favorit. Pindah ke kategori lain lalu klik bintang.</p>'}</div></div>
  <div class="card"><h2>Ketik lalu bacakan</h2><p class="hint">Teks yang kamu ketik dibacakan TTS di live (pakai pengaturan suara di tab Suara &amp; TTS).</p>
  <div class="row" style="margin:0"><input id="sayTxt" placeholder="contoh: Terima kasih semuanya yang sudah mampir!" style="flex:1;min-width:220px"><button class="p sm" data-act="say">Bacakan</button></div></div>`;
}
function wheelTab() {
  return `<div class="card"><h2>Roda Putar</h2><p class="hint">Roda hadiah yang muncul di live (pasang <code>wheel.html</code> di OBS). Bisa diputar otomatis tiap ada gift tertentu, atau manual lewat tombol. Pemenang dipilih acak, lalu diumumkan lewat suara.</p>
  <div class="grid">${F.chk('wheel.enabled', 'Putar otomatis kalau ada gift yang cocok')}${F.txt('wheel.title', 'Judul roda', 'Roda Hadiah')}
  ${F.txt('wheel.gift', 'Gift pemicu (kosong = semua gift)', 'contoh: Rose')}${F.num('wheel.minDiamond', 'Min. diamond', 0, 1000000)}
  ${F.snd('wheel.sound', 'Suara saat hasil keluar')}${F.txt('wheel.ttsText', 'Kalimat TTS hasil', 'Selamat {nick}, hadiahnya {prize}')}
  <label class="fld wide"><span>Hadiah (satu per baris, 2 sampai 16)</span><textarea data-p="wheel.items" data-t="s" rows="7"></textarea></label></div>
  <div class="row"><button class="p" data-act="wheelSpin">Putar sekarang</button></div></div>`;
}
const BOARD_CSS = '.sbgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:9px;margin-top:6px}.sbx{display:flex;gap:4px}.sb{flex:1;text-align:left;font-size:14px;position:relative;padding:12px 10px;border-radius:14px;background:linear-gradient(135deg,rgba(251,191,36,.18),rgba(236,72,153,.16))}.sb .k{font-style:normal;background:var(--amber);color:#2a1d00;border-radius:6px;padding:0 6px;margin-right:6px;font-size:12px;font-weight:800}.st{padding:4px 9px;color:#6f6990}.st.on{color:var(--amber)}';
document.head.appendChild(Object.assign(document.createElement('style'), { textContent: BOARD_CSS }));
document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.altKey || e.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)) return;
  const n = /^[1-9]$/.test(e.key) ? +e.key : 0, u = n && (ui.fav || [])[n - 1];
  if (u) { s.emit('soundboard', { sound: u }); toast('Soundboard: ' + (boardItems().find(x => x.u === u)?.label || '')); }
});


// ---------- Gaya overlay: opsi kustom + paket sekali klik ----------
const FONT_OPT = [['bawaan', 'Bawaan tema'], ['poppins', 'Poppins (rapi)'], ['lilita', 'Lilita One (gemuk lucu)'], ['bangers', 'Bangers (komik)'], ['pacifico', 'Pacifico (tulisan tangan)'], ['orbitron', 'Orbitron (futuristik)'], ['pixel', 'Press Start 2P (pixel)']];
const ANIM_OPT = [['pop', 'Turun dari atas'], ['slide', 'Geser dari samping'], ['bounce', 'Memantul'], ['zoom', 'Zoom'], ['flip', 'Membalik']];
const WS_OPT = [['kaca', 'Gelap bawaan'], ['neon', 'Neon'], ['emas', 'Emas'], ['pixel', 'Pixel'], ['minimal', 'Putih bersih'], ['sakura', 'Pink manis'], ['komik', 'Komik']];
const PACKS = [
  { id: 'neon', name: 'Neon Gamer', desc: 'Gelap, menyala, futuristik', mode: 'gaming', look: { theme: 'neon', bigTheme: 'cyber', effect: 'glow', bigEffect: 'confetti', font: 'orbitron', anim: 'slide', textScale: 1, widgetStyle: 'neon', bigSound: '/sfx/airhorn.mp3' } },
  { id: 'kawaii', name: 'Kawaii Pink', desc: 'Pink manis dan memantul', mode: 'santai', look: { theme: 'sakura', bigTheme: 'sakura', effect: 'none', bigEffect: 'confetti', font: 'lilita', anim: 'bounce', textScale: 1, widgetStyle: 'sakura', bigSound: '/sfx/tada.mp3' } },
  { id: 'sultan', name: 'Sultan Royal', desc: 'Ungu dan emas mewah', mode: 'jualan', look: { theme: 'royal', bigTheme: 'emas', effect: 'glow', bigEffect: 'confetti', font: 'bawaan', anim: 'zoom', textScale: 1, widgetStyle: 'emas', bigSound: '/sfx/kaching.mp3' } },
  { id: 'arcade', name: 'Retro Arcade', desc: 'Pixel ala game jadul', mode: 'gaming', look: { theme: 'retro', bigTheme: 'pixel', effect: 'none', bigEffect: 'shake', font: 'pixel', anim: 'pop', textScale: 0.8, widgetStyle: 'pixel', bigSound: '/sfx/airhorn.mp3' } },
  { id: 'clean', name: 'Clean Minimal', desc: 'Putih bersih, rapi', mode: 'santai', look: { theme: 'minimal', bigTheme: 'gradient', effect: 'none', bigEffect: 'glow', font: 'poppins', anim: 'slide', textScale: 1, widgetStyle: 'minimal', bigSound: '/sfx/tada.mp3' } },
  { id: 'komik', name: 'Komik Pop', desc: 'Kuning ngejreng ala komik', mode: 'gaming', look: { theme: 'comic', bigTheme: 'comic', effect: 'none', bigEffect: 'shake', font: 'bangers', anim: 'bounce', textScale: 1.1, widgetStyle: 'komik', bigSound: '/sfx/vineboom.mp3' } },
];
function packsInner() {
  const cur = draft && draft.look ? draft.look.theme + '|' + draft.look.widgetStyle + '|' + draft.look.font : '';
  return PACKS.map(p => `<button class="tp ${cur === p.look.theme + '|' + p.look.widgetStyle + '|' + p.look.font ? 'sel' : ''}" data-act="pack" data-v="${p.id}"><div class="pvbg"><div style="zoom:.4">${alHtml(p.look.theme, 'none', 'Andi kirim Rose ×5', '5 diamond')}</div></div><b>${esc(p.name)}</b><small class="hint">${esc(p.desc)}</small></button>`).join('');
}
function packsCard() {
  return `<div class="card hero"><h2>Galeri gaya (sekali klik)</h2><p class="hint">Satu klik langsung mengatur tema alert, font, animasi, gaya widget, suara gift besar, sound gift, TTS, pengingat, dan command. Setelah itu tinggal disesuaikan di bawah.</p><div class="themes">${packsInner()}</div></div>
  <div class="card"><h2>Kustom overlay</h2><p class="hint">Berlaku untuk alert, chat, goal, top gifter, poll, dan widget lain sekaligus. Semua tersimpan otomatis.</p>
  <div class="grid">${F.sel('look.font', 'Font', FONT_OPT)}${F.sel('look.anim', 'Animasi muncul', ANIM_OPT)}${F.rng('look.textScale', 'Ukuran alert', 0.6, 1.8, 0.05)}${F.sel('look.widgetStyle', 'Gaya kotak widget', WS_OPT)}
  <label class="fld"><span>Warna aksen (kosongkan = otomatis per jenis alert)</span><input type="color" data-p="look.accent" data-t="s"></label></div>
  <div class="row"><button class="sm" data-act="accentReset">Warna otomatis</button><button class="p sm" data-act="replay">Tes alert</button></div></div>`;
}
function applyPack(id) {
  const p = PACKS.find(x => x.id === id); if (!p) return;
  applyPreset(p.mode);
  Object.assign(draft.look, p.look, { accent: '' });
  renderAll(); save(); toast('Gaya "' + p.name + '" terpasang. Klik Tes alert buat lihat hasilnya.');
}

// ---------- Paket cepat & rekap ----------
function applyPreset(k) {
  const D = draft, have = new Set(D.giftSounds.map(r => r.gift.trim().toLowerCase()));
  for (const [g, f] of PRESET) { const x = sfxList.find(y => y.file.startsWith(f + '.')); if (x && !have.has(g.toLowerCase())) D.giftSounds.push({ ...ROW_SND, id: rid(), gift: g, sound: '/sfx/' + x.file }); }
  const cmd = (c, a, t) => { if (!D.commands.some(r => r.cmd === c)) D.commands.push({ ...ROW_CMD, id: rid(), cmd: c, alertText: a, ttsText: t, cooldown: 15 }); };
  D.reminders.forEach(r => r.enabled = true);
  D.events.gift.tts = true; D.events.follow.tts = true; D.look.bigEffect = 'confetti';
  if (k === 'gaming') { D.look.theme = 'neon'; D.look.bigTheme = 'emas'; D.look.bigSound = '/sfx/airhorn.mp3'; D.events.join.tts = false; D.events.like.tts = true; cmd('!sosmed', 'Ikuti sosmed kami', 'Jangan lupa follow sosial media kami ya'); }
  if (k === 'jualan') { D.look.theme = 'gradien'; D.look.bigTheme = 'emas'; D.look.bigSound = '/sfx/kaching.mp3'; D.events.join.tts = true; D.events.share.tts = true; cmd('!order', 'Cara order', 'Untuk order, klik keranjang kuning di bawah layar ya'); cmd('!harga', 'Cek harga', 'Harga ada di keranjang kuning, silakan dicek ya'); }
  if (k === 'santai') { D.look.theme = 'kaca'; D.look.bigTheme = 'emas'; D.look.bigSound = '/sfx/tada.mp3'; D.events.join.tts = true; D.events.chat.tts = true; D.events.chat.only = 'follower'; }
  renderAll(); save(); toast('Paket "' + k + '" diterapkan. Cek tiap tab kalau mau diubah.');
}
function recapPng() {
  const c = document.createElement('canvas'); c.width = 1080; c.height = 1350; const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 1080, 1350); g.addColorStop(0, '#2a1140'); g.addColorStop(1, '#0b0a16'); x.fillStyle = g; x.fillRect(0, 0, 1080, 1350);
  x.fillStyle = '#ff4d8d'; x.font = '800 64px system-ui'; x.fillText('REKAP LIVE', 70, 130);
  x.fillStyle = '#fff'; x.font = '600 38px system-ui'; x.fillText('@' + (st.user || 'streamer') + ' - ' + new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }), 70, 190);
  const stats = [['Diamond', st.diamonds], ['Like', st.likes], ['Follower baru', st.followers], ['Share', st.shares], ['Gift', st.gifts], ['Komentar', st.chats]];
  stats.forEach(([l, v], i) => { const cx = 70 + (i % 2) * 480, cy = 250 + Math.floor(i / 2) * 170; x.fillStyle = 'rgba(255,255,255,.08)'; x.beginPath(); x.roundRect(cx, cy, 450, 140, 24); x.fill(); x.fillStyle = '#fbbf24'; x.font = '800 62px system-ui'; x.fillText(fmtNum(v), cx + 28, cy + 80); x.fillStyle = '#c9c3ea'; x.font = '600 30px system-ui'; x.fillText(l, cx + 28, cy + 118); });
  x.fillStyle = '#fff'; x.font = '800 44px system-ui'; x.fillText('Top Gifter', 70, 820);
  (st.top || []).slice(0, 5).forEach((t, i) => { x.fillStyle = i ? '#e8e4ff' : '#fbbf24'; x.font = '700 38px system-ui'; x.fillText((i + 1) + '. ' + String(t.nick || '-').slice(0, 22), 70, 890 + i * 70); x.textAlign = 'right'; x.fillText(fmtNum(t.diamonds) + ' diamond', 1010, 890 + i * 70); x.textAlign = 'left'; });
  if (!(st.top || []).length) { x.fillStyle = '#a29cc4'; x.font = '600 32px system-ui'; x.fillText('Belum ada gift di sesi ini', 70, 890); }
  x.fillStyle = '#a29cc4'; x.font = '600 28px system-ui'; x.fillText('Dibuat dengan RYZFinity', 70, 1290);
  c.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'rekap-live.png'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); });
}

// ---------- Tab Musik ----------
const trackName = u => { const l = musicLib.find(m => '/music/' + m.file === u); return l ? l.label : decodeURIComponent(String(u).split('/').pop()).replace(/\.[^.]+$/, '').replace(/^[a-z0-9]{6,8}_/i, '').replace(/[_-]+/g, ' '); };
function musicTab() {
  const pls = draft.music.playlists, now = mv.playing ? mv.tracks[mv.cur] : '';
  const lib = [...musicLib.map(m => ['/music/' + m.file, m.label + ' (bawaan)']), ...media.filter(m => m.type === 'audio').map(m => [m.url, m.name + ' (upload)'])];
  const cards = pls.map((p, i) => `<div class="card"><h2>${esc(p.name)}<span class="sp"></span><button class="sm p" data-act="playPl" data-id="${p.id}">Putar playlist</button><button class="sm d" data-act="delPl" data-i="${i}">Hapus</button></h2>
    <div class="grid" style="margin:8px 0 12px">${F.txt(`music.playlists.${i}.name`, 'Nama playlist')}</div>
    ${p.tracks.map((t, j) => `<div class="trk ${mv.playing && mv.pl === p.id && mv.cur === j ? 'now' : ''}"><span class="no">${j + 1}</span><span class="nm">${esc(trackName(t))}</span><button class="sm" data-act="playTrack" data-id="${p.id}" data-j="${j}" aria-label="Putar lagu ini">${PLAY}</button><button class="sm" data-act="upTrack" data-i="${i}" data-j="${j}" aria-label="Naik">&uarr;</button><button class="sm" data-act="downTrack" data-i="${i}" data-j="${j}" aria-label="Turun">&darr;</button><button class="sm d" data-act="rmTrack" data-i="${i}" data-j="${j}" aria-label="Hapus lagu">&times;</button></div>`).join('') || '<p class="hint">Playlist masih kosong.</p>'}
    <div class="addtrk"><select data-u="trk_${i}">${lib.map(([u, n]) => `<option value="${esc(u)}">${esc(n)}</option>`).join('')}</select><button class="sm" data-act="addTrack" data-i="${i}">+ Tambah lagu</button></div></div>`).join('');
  return `<div class="card player ${mv.playing ? 'on' : ''}"><h2>Pemutar musik</h2>
  <div class="np"><div class="eqb"><i></i><i></i><i></i><i></i></div><div><div class="hint" style="margin:0">${mv.playing ? 'Sedang diputar' : 'Berhenti'}${mv.plName ? ' - ' + esc(mv.plName) : ''}</div><div class="npt">${now ? esc(trackName(now)) : 'Belum ada lagu diputar'}</div></div></div>
  <div class="row"><button data-act="musicPrev">Sebelumnya</button><button class="p" data-act="musicToggle">${mv.playing ? 'Jeda' : 'Putar'}</button><button data-act="musicNext">Berikutnya</button></div>
  <div class="grid" style="margin-top:16px">${F.rng('music.volume', 'Volume musik', 0, 1, 0.05)}${F.sel('music.repeat', 'Ulangi', [['all', 'Semua lagu'], ['one', 'Satu lagu'], ['off', 'Tidak diulang']])}${F.rng('music.duckLevel', 'Volume saat alert bersuara', 0, 1, 0.05)}</div>
  <div class="row" style="gap:22px">${F.chk('music.shuffle', 'Acak urutan')}${F.chk('music.duck', 'Kecilkan musik saat alert / TTS bunyi')}</div>
  <p class="hint" style="margin-top:12px">Pasang <code>${location.origin}/music.html</code> sebagai Browser Source di OBS / LIVE Studio (aktifkan "Control audio via OBS"). Musik diputar dari sana, dikontrol dari tab ini. Tambah <code>?np=0</code> untuk menyembunyikan kartu judul lagu. Upload mp3 sendiri lewat tab Media, lalu tambahkan ke playlist.</p></div>
  ${cards}<div class="row" style="margin-top:0"><button class="p" data-act="newPl">+ Buat playlist baru</button></div>`;
}
function updMusic() {
  const p = $('p-music'); if (!p || !draft) return;
  if (document.activeElement && document.activeElement !== document.body && p.contains(document.activeElement) && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
  p.innerHTML = musicTab(); bind();
}
let pvAudio = null;
function playPrev(u, vol = 1) { if (pvAudio) pvAudio.pause(); pvAudio = new Audio(u); pvAudio.volume = vol; pvAudio.play().catch(() => toast('Suara tidak bisa diputar')); }

// ---------- Render ----------
const TABFN = { voice: voiceTab, events: eventsTab, look: lookTab, gifts: giftsTab, cmds: cmdsTab, interact: interactTab, sounds: soundsTab, board: boardTab, wheel: wheelTab, music: musicTab, goals: goalsTab, overlays: overlaysTab, media: mediaTab };
function renderAll() {
  if (!draft) return;
  for (const [k, fn] of Object.entries(TABFN)) $('p-' + k).innerHTML = fn();
  const pl = $('packLive'); if (pl) pl.innerHTML = packsInner();
  bind(); updInteract(); initUpload(); refreshPreviews();
}
function bind() {
  document.querySelectorAll('[data-p]').forEach(el => {
    const v = get(draft, el.dataset.p);
    if (el.type === 'checkbox') el.checked = !!v;
    else {
      if (el.tagName === 'SELECT' && v != null && v !== '' && ![...el.options].some(o => o.value === String(v))) el.add(new Option(String(v) + ' (tidak ditemukan)', String(v)));
      el.value = v ?? '';
    }
    const o = document.querySelector(`[data-o="${el.dataset.p}"]`); if (o) o.textContent = v;
  });
}
function showTab(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.id === 'p-' + id));
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.tab === id));
  const t = TABS.find(x => x[0] === id); if (t) document.documentElement.style.setProperty('--ac', t[2]);
  location.hash = id;
}
$('nav').innerHTML = TABS.map(([k, t, c]) => `<button data-tab="${k}" style="--tc:${c}"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[k]}</svg><span>${t}</span></button>`).join('');
$('nav').onclick = e => { const b = e.target.closest('button[data-tab]'); if (b) showTab(b.dataset.tab); };
showTab(TABS.some(t => t[0] === location.hash.slice(1)) ? location.hash.slice(1) : 'live');

// ---------- Simpan otomatis ----------
function edited() { lastEdit = Date.now(); $('ind').textContent = 'Menyimpan...'; clearTimeout(saveT); saveT = setTimeout(save, 500); }
function save() { clearTimeout(saveT); saveT = null; if (!draft) return; s.emit('saveSettings', draft); $('ind').textContent = 'Tersimpan'; setTimeout(() => { if ($('ind').textContent === 'Tersimpan') $('ind').textContent = ''; }, 1800); }
const flush = () => { if (saveT) save(); };
function onField(ev) {
  const el = ev.target;
  if (el.dataset.u) { ui[el.dataset.u] = el.value; localStorage.setItem('ry_ui', JSON.stringify(ui)); return; }
  if (!el.dataset.p || !draft) return;
  const v = el.type === 'checkbox' ? el.checked : el.dataset.t === 'n' ? (el.value === '' ? 0 : +el.value) : el.value;
  set(draft, el.dataset.p, v);
  const o = document.querySelector(`[data-o="${el.dataset.p}"]`); if (o) o.textContent = v;
  if (el.type === 'checkbox' && /\.(enabled)$/.test(el.dataset.p)) renderAll();
  if (/^(look|events\.gift)\./.test(el.dataset.p)) refreshPreviews();
  edited();
}
document.querySelector('main').addEventListener('input', onField);
document.querySelector('main').addEventListener('change', onField);

// ---------- Aksi tombol ----------
function tev(o) {
  flush();
  if ($('simOn')?.checked) { const n = 1 + Math.floor(Math.random() * 6); Object.assign(o, { sim: true, user: 'sim' + n, nick: 'Penonton ' + n }); }
  s.emit('testEvent', o);
}
function simMany(text, n = 10) { flush(); for (let i = 1; i <= n; i++) s.emit('testEvent', { type: 'chat', sim: true, user: 'sim' + i, nick: 'Penonton ' + i, text: typeof text === 'function' ? text() : text }); }
const rid = () => 'r' + Math.random().toString(36).slice(2, 9);
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const d = b.dataset, a = d.act;
  if (a === 'testEvent') tev({ type: d.type });
  else if (a === 'testGift') tev({ type: 'gift', gift: $('tgName').value || 'Rose', diamonds: +$('tgDia').value || 1 });
  else if (a === 'simPoll') { const n = Math.max(2, String(uiv('po')).split('\n').filter(x => x.trim()).length); simMany(() => String(1 + Math.floor(Math.random() * n))); }
  else if (a === 'simGw') simMany(draft.giveaway.keyword || '!ikut');
  else if (a === 'pickTheme') { set(draft, d.key, d.v); renderAll(); edited(); }
  else if (a === 'replay') refreshPreviews();
  else if (a === 'testSmall') tev({ type: 'gift', gift: 'Tes Gift', diamonds: 1 });
  else if (a === 'testBig') tev({ type: 'gift', gift: 'Tes Gift Besar', diamonds: Math.max(1, draft.look.bigMin) });
  else if (a === 'testRow') { flush(); s.emit('testRow', { kind: d.kind, id: d.id }); }
  else if (a === 'addRow') { draft[d.list].push({ ...({ giftActions: ROW_GIFT, commands: ROW_CMD, giftSounds: ROW_SND, reminders: ROW_REM })[d.list], id: rid() }); renderAll(); save(); }
  else if (a === 'delRow') { draft[d.list].splice(+d.i, 1); renderAll(); save(); }
  else if (a === 'playSfx') playPrev(d.u);
  else if (a === 'sfxCat') { ui.sfxCat = d.v; localStorage.setItem('ry_ui', JSON.stringify(ui)); $('p-sounds').innerHTML = soundsTab(); bind(); }
  else if (a === 'playSnd') { const r = draft.giftSounds[+d.i]; if (r.sound) playPrev(r.sound, r.volume); else toast('Pilih sound dulu'); }
  else if (a === 'testSnd') { const r = draft.giftSounds[+d.i]; tev({ type: 'gift', gift: r.gift.trim() || 'Tes Gift', diamonds: Math.max(1, r.minDiamond) }); }
  else if (a === 'pickAudio') $('fileS').click();
  else if (a === 'addSoundFor') { draft.giftSounds.push({ ...ROW_SND, id: rid(), gift: d.gift }); renderAll(); save(); }
  else if (a === 'addAllSeen') { const have = new Set(draft.giftSounds.map(r => r.gift.trim().toLowerCase())); for (const g of seen) if (!have.has(g.name.toLowerCase())) draft.giftSounds.push({ ...ROW_SND, id: rid(), gift: g.name }); renderAll(); save(); }
  else if (a === 'fillPreset') { const have = new Set(draft.giftSounds.map(r => r.gift.trim().toLowerCase())); for (const [g, f] of PRESET) { const x = sfxList.find(y => y.file.startsWith(f + '.')); if (x && !have.has(g.toLowerCase())) draft.giftSounds.push({ ...ROW_SND, id: rid(), gift: g, sound: '/sfx/' + x.file }); } renderAll(); save(); }
  else if (a === 'musicToggle') { flush(); s.emit(mv.playing ? 'musicPause' : 'musicResume'); }
  else if (a === 'musicNext') s.emit('musicNext');
  else if (a === 'musicPrev') s.emit('musicPrev');
  else if (a === 'newPl') { draft.music.playlists.push({ id: rid(), name: 'Playlist baru', tracks: [] }); renderAll(); save(); }
  else if (a === 'delPl') { if (confirm('Hapus playlist ini?')) { draft.music.playlists.splice(+d.i, 1); renderAll(); save(); } }
  else if (a === 'playPl') { flush(); s.emit('musicPlay', { pl: d.id, index: 0 }); }
  else if (a === 'playTrack') { flush(); s.emit('musicPlay', { pl: d.id, index: +d.j }); }
  else if (a === 'addTrack') { const sel = document.querySelector(`[data-u="trk_${d.i}"]`); if (sel && sel.value) { draft.music.playlists[+d.i].tracks.push(sel.value); renderAll(); save(); } else toast('Belum ada lagu. Upload dulu di tab Media.'); }
  else if (a === 'rmTrack') { draft.music.playlists[+d.i].tracks.splice(+d.j, 1); renderAll(); save(); }
  else if (a === 'upTrack' || a === 'downTrack') { const t = draft.music.playlists[+d.i].tracks, j = +d.j, k = a === 'upTrack' ? j - 1 : j + 1; if (k >= 0 && k < t.length) { [t[j], t[k]] = [t[k], t[j]]; renderAll(); save(); } }
  else if (a === 'voiceLocal') RY.speak('Halo, ini tes suara dari RYZ Finity. Terima kasih sudah menonton!', draft.voice);
  else if (a === 'voiceStop') RY.stopSpeech();
  else if (a === 'resetTop') s.emit('resetTop');
  else if (a === 'resetGoal') s.emit('resetGoal', d.t);
  else if (a === 'pollStart') { s.emit('pollStart', { question: uiv('pq'), options: String(uiv('po')).split('\n'), duration: +uiv('pd') }); }
  else if (a === 'pollStop') s.emit('pollStop');
  else if (a === 'pollHide') s.emit('pollHide');
  else if (a === 'gwStart') { flush(); s.emit('giveawayStart'); }
  else if (a === 'gwStop') s.emit('giveawayStop');
  else if (a === 'gwDraw') s.emit('giveawayDraw', d.from);
  else if (a === 'gwReset') s.emit('giveawayReset');
  else if (a === 'timerStart') { flush(); s.emit('timerStart'); }
  else if (a === 'timerPause') s.emit('timerPause');
  else if (a === 'timerResume') s.emit('timerResume');
  else if (a === 'timerAdd') s.emit('timerAdd', +d.n);
  else if (a === 'timerReset') s.emit('timerReset');
  else if (a === 'copy') { try { await navigator.clipboard.writeText(d.u); b.textContent = 'Tersalin'; setTimeout(() => b.textContent = 'Salin', 1200); } catch { prompt('Salin URL:', d.u); } }
  else if (a === 'importUrl') { const el = $('impUrl'), url = el && el.value.trim(); if (!url) return toast('Tempel link mp3 dulu'); toast('Mengunduh...'); try { const r = await fetch('/api/import', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-pw': pw }, body: JSON.stringify({ url }) }); const j = await r.json(); toast(r.ok ? 'Terimpor: ' + j.name : (j.error || 'Gagal impor')); if (r.ok) el.value = ''; } catch (e) { toast('Gagal impor: ' + e.message); } }
  else if (a === 'sbPlay') s.emit('soundboard', { sound: d.u });
  else if (a === 'sbStop') s.emit('skipCue');
  else if (a === 'sbFav') { const f = ui.fav || []; ui.fav = f.includes(d.u) ? f.filter(u => u !== d.u) : [...f, d.u]; localStorage.setItem('ry_ui', JSON.stringify(ui)); $('p-board').innerHTML = boardTab(); }
  else if (a === 'boardCat') { ui.boardCat = d.v; localStorage.setItem('ry_ui', JSON.stringify(ui)); $('p-board').innerHTML = boardTab(); }
  else if (a === 'say') { const el = $('sayTxt'); if (el && el.value.trim()) { s.emit('say', el.value.trim()); el.value = ''; } else toast('Ketik dulu teksnya'); }
  else if (a === 'wheelSpin') { flush(); s.emit('wheelSpin'); }
  else if (a === 'preset') applyPreset(d.v);
  else if (a === 'recap') recapPng();
  else if (a === 'pack') applyPack(d.v);
  else if (a === 'accentReset') { draft.look.accent = ''; renderAll(); edited(); }
  else if (a === 'copyOv') { const u = location.origin + '/overlay.html'; (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(() => toast('Link tersalin: ' + u), () => prompt('Salin link ini:', u)); }
  else if (a === 'pick') $('file').click();
  else if (a === 'delMedia') { if (!confirm('Hapus ' + d.name + '?')) return; const r = await fetch('/api/media/delete', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-pw': pw }, body: JSON.stringify({ name: d.name }) }); toast(r.ok ? 'File dihapus' : 'Gagal menghapus'); }
});
$('fileS').onchange = () => { upload([...$('fileS').files]); $('fileS').value = ''; };
$('go').onclick = () => s.emit('connectTo', $('u').value);
if ($('goMine')) $('goMine').onclick = () => { const m = ($('myUser').value || '').trim(); if (!m) return toast('Isi username akun TikTok kamu dulu'); flush(); $('u').value = m; s.emit('connectTo', m); };
$('stop').onclick = () => s.emit('disconnectLive');
$('skip').onclick = () => s.emit('skipCue');

// ---------- Upload ----------
async function upload(files) {
  for (const f of files) {
    try {
      const r = await fetch('/api/upload?name=' + encodeURIComponent(f.name), { method: 'POST', headers: { 'x-pw': pw, 'Content-Type': 'application/octet-stream' }, body: f });
      const j = await r.json().catch(() => ({}));
      toast(r.ok ? 'Terupload: ' + j.name : (j.error || 'Gagal upload ' + f.name));
    } catch (e) { toast('Gagal upload: ' + e.message); }
  }
}
function initUpload() {
  const dz = $('drop'), fi = $('file'); if (!dz) return;
  fi.onchange = () => { upload([...fi.files]); fi.value = ''; };
  dz.ondragover = e => { e.preventDefault(); dz.classList.add('over'); };
  dz.ondragleave = () => dz.classList.remove('over');
  dz.ondrop = e => { e.preventDefault(); dz.classList.remove('over'); upload([...e.dataTransfer.files]); };
}

// ---------- Info live di tab Interaksi / Goal ----------
const p2 = n => String(n).padStart(2, '0');
function updInteract() {
  const g = $('gwInfo');
  if (g) g.innerHTML = `${gw.active ? 'Sedang menerima peserta' : 'Tidak menerima peserta'} - <b>${gw.count}</b> peserta${gw.keyword ? ' (kata kunci <code>' + esc(gw.keyword) + '</code>)' : ''}.${gw.winners.length ? '<br>Pemenang: ' + gw.winners.map(w => '<b>' + esc(w.nick || w.user) + '</b>').join(', ') : ''}`;
  tickTimer();
}
function tickTimer() {
  const el = $('tmNow'); if (!el) return;
  if (!tm || !tm.started) { el.textContent = '--:--'; return; }
  const ms = tm.running ? Math.max(0, tm.endsAt - (Date.now() + tmOff)) : tm.remaining, sec = Math.ceil(ms / 1000), h = Math.floor(sec / 3600);
  el.textContent = (h ? h + ':' : '') + p2(Math.floor(sec % 3600 / 60)) + ':' + p2(sec % 60) + (tm.running ? '' : ' (jeda)');
}
setInterval(tickTimer, 500);
function updGoals() {
  if (!draft) return;
  for (const k of ['diamond', 'likes', 'followers']) {
    const v = st.goal?.[k] || 0, tg = draft.goals[k].target || 1, a = document.querySelector(`[data-gv="${k}"]`), b = document.querySelector(`[data-gb="${k}"]`);
    if (a) a.textContent = `${fmtNum(v)} / ${fmtNum(tg)}`; if (b) b.style.width = Math.min(100, v / tg * 100) + '%';
  }
}

// ---------- Socket ----------
s.on('auth', a => {
  $('login').style.display = a.admin ? 'none' : 'grid';
  if (!a.admin && pw) $('lerr').textContent = 'Password salah';
});
$('lf').onsubmit = e => { e.preventDefault(); localStorage.setItem('ry_pw', $('lpw').value); location.reload(); };
s.on('settings', o => {
  if (draft && Date.now() - lastEdit < 2000) return;
  if (draft && JSON.stringify(o) === JSON.stringify(draft)) { cfg = o; return; }
  cfg = o; draft = JSON.parse(JSON.stringify(o)); renderAll();
});
s.on('media', m => { media = m; renderAll(); });
s.on('state', x => {
  st = x; $('sV').textContent = fmtNum(x.viewers); $('sL').textContent = fmtNum(x.likes); $('sF').textContent = fmtNum(x.followers); $('sD').textContent = fmtNum(x.diamonds); $('sS').textContent = fmtNum(x.shares);
  $('st').textContent = x.connected ? 'LIVE @' + x.user : (x.user ? 'Menyambung @' + x.user + '...' : 'Belum tersambung'); $('st').className = x.connected ? 'on' : '';
  if (x.user && !$('u').value) $('u').value = x.user;
  updGoals();
});
s.on('timer', t => { tm = t; tmOff = t.now - Date.now(); tickTimer(); });
s.on('giveaway', g => { gw = g; updInteract(); });
s.on('poll', p => { pl = p; });
s.on('music', m => { mv = m; updMusic(); });
s.on('gifts', g => {
  seen = g.sort((a, b) => (b.diamonds || 0) - (a.diamonds || 0));
  $('giftNames').innerHTML = [...new Set([...seen.map(x => x.name), ...COMMON_GIFTS])].map(n => `<option>${esc(n)}</option>`).join('');
  if (draft && !document.activeElement?.closest('#p-sounds')) { $('p-sounds').innerHTML = soundsTab(); bind(); }
});
fetch('/sfx/sfx.json').then(r => r.json()).then(l => { sfxList = l; renderAll(); }).catch(() => {});
fetch('/music/music.json').then(r => r.json()).then(l => { musicLib = l; renderAll(); }).catch(() => {});
$('giftNames').innerHTML = COMMON_GIFTS.map(n => `<option>${esc(n)}</option>`).join('');
if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => { if (draft && !document.activeElement?.closest('#p-voice')) { $('p-voice').innerHTML = voiceTab(); bind(); } };

const BADGE = { mod: 'MOD', sub: 'SUB', gifter: 'GIFTER', follower: 'FOLLOW' };
function avatarEl(e) {
  const nick = e.nick || e.user || '?';
  const ph = () => { const p = document.createElement('div'); p.className = 'fa ph'; p.textContent = nick.trim().charAt(0).toUpperCase() || '?'; return p; };
  if (!e.avatar) return ph();
  const im = document.createElement('img'); im.className = 'fa'; im.referrerPolicy = 'no-referrer'; im.alt = ''; im.src = e.avatar; im.onerror = () => im.replaceWith(ph()); return im;
}
s.on('event', e => {
  if (e.type === 'join') return;
  const f = $('feed'), d = document.createElement('div'); d.className = 'ev ' + e.type;
  if (e.type === 'system') d.textContent = e.text;
  else {
    const tm = new Date(e.t || Date.now()).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const act = { chat: e.text ? esc(e.text) : '<small>(emote / stiker)</small>', gift: `kirim <b>${esc(e.gift)}</b> ×${e.count} <small>(${e.diamonds} diamond)</small>`, follow: 'mulai mengikuti', share: 'membagikan live', subscribe: 'subscribe' }[e.type] || '';
    const bd = (e.badges || []).map(b => `<i class="bd ${b}">${BADGE[b] || b}</i>`).join('');
    const body = document.createElement('div'); body.className = 'fb';
    body.innerHTML = `<div class="fh"><b>${esc(e.nick || e.user)}</b>${e.user ? `<em>@${esc(e.user)}</em>` : ''}${bd}<span class="ft">${tm}</span></div><div class="fx">${act}</div>`;
    d.append(avatarEl(e), body);
    if (e.type === 'gift' && e.giftImg) { const g = document.createElement('img'); g.className = 'gi2'; g.referrerPolicy = 'no-referrer'; g.alt = ''; g.src = e.giftImg; g.onerror = () => g.remove(); d.appendChild(g); }
  }
  f.appendChild(d); while (f.children.length > 150) f.firstChild.remove(); f.scrollTop = f.scrollHeight;
});
