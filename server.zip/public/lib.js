// Library bersama untuk dashboard & semua overlay
(function () {
  const q = new URLSearchParams(location.search);
  const $ = id => document.getElementById(id);
  const esc = t => String(t ?? '').replace(/[&<>"]/g, x => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[x]));
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ?pos=tl|tr|bl|br|tc|bc|cl|cr|c  dan  ?scale=1.5
  function place(el, def) {
    el.classList.add('w', 'pos-' + (q.get('pos') || def));
    const sc = parseFloat(q.get('scale'));
    if (sc > 0 && sc !== 1) document.body.style.zoom = sc;
  }
  const fmtNum = n => Number(n || 0).toLocaleString('id-ID');

  // ---------- Suara ----------
  let cur = null, gen = 0; // audio/utterance yang sedang jalan; gen naik tiap stop supaya antrean chunk berhenti
  const shortLang = l => String(l || 'id-ID').split('-')[0];
  function chunks(text, max = 180) {
    const out = []; let s = String(text).trim();
    while (s.length > max) { let i = s.lastIndexOf(' ', max); if (i < 40) i = max; out.push(s.slice(0, i).trim()); s = s.slice(i).trim(); }
    if (s) out.push(s); return out;
  }
  function playUrl(url, volume = 1, rate = 1) {
    return new Promise((resolve, reject) => {
      const a = new Audio(url); a.volume = Math.min(1, Math.max(0, volume)); a.playbackRate = rate; cur = a;
      a.onended = () => resolve(); a.onerror = () => reject(new Error('audio error'));
      a.play().catch(reject);
    });
  }
  function speakBrowser(text, v) {
    return new Promise(resolve => {
      if (!window.speechSynthesis) return resolve();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = v.lang || 'id-ID'; u.rate = v.rate || 1; u.pitch = v.pitch || 1; u.volume = v.volume ?? 1;
      const voices = speechSynthesis.getVoices();
      const pick = voices.find(x => x.name === v.name) || voices.find(x => x.lang === u.lang) || voices.find(x => x.lang.startsWith(shortLang(u.lang)));
      if (pick) u.voice = pick;
      let done = false; const end = () => { if (!done) { done = true; resolve(); } };
      u.onend = end; u.onerror = end; cur = u;
      setTimeout(end, 4000 + text.length * 150); // jaga-jaga kalau event end tidak datang
      speechSynthesis.speak(u);
    });
  }
  // Mengembalikan Promise yang selesai saat suara selesai
  async function speak(text, v) {
    v = v || {}; if (!text) return;
    const g = gen;
    if (v.engine === 'google') {
      try { for (const c of chunks(text)) { if (g !== gen) return; await playUrl(`/tts?lang=${shortLang(v.lang)}&text=${encodeURIComponent(c)}`, v.volume ?? 1, v.rate || 1); } return; }
      catch (e) { if (g !== gen) return; /* fallback ke suara browser */ }
    }
    if (g !== gen) return;
    return speakBrowser(text, v);
  }
  function stopSpeech() { gen++; try { speechSynthesis.cancel(); } catch {} if (cur && cur.pause) { try { cur.pause(); cur.dispatchEvent(new Event('ended')); } catch {} } }

  function connect(extra) {
    const s = io(extra || {});
    return s;
  }
  // Confetti di atas elemen (dipakai efek gift besar)
  function burst(el, n = 44) {
    const box = document.createElement('div'); box.className = 'cf';
    const cols = ['#ff4d8d', '#ffb347', '#3ddc97', '#6c8cff', '#fff0a8', '#b784ff'];
    for (let i = 0; i < n; i++) {
      const p = document.createElement('i'), a = Math.random() * Math.PI * 2, d = 120 + Math.random() * 260;
      p.style.cssText = `background:${cols[i % cols.length]};--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d - 60}px;--rot:${Math.random() * 720 - 360}deg;animation-delay:${Math.random() * 120}ms`;
      box.appendChild(p);
    }
    el.appendChild(box); setTimeout(() => box.remove(), 2000);
  }

  // ---------- Gaya global (font, warna aksen, gaya kotak widget) ----------
  const FONTS = { bangers: ['Bangers', 'Bangers'], lilita: ['Lilita One', 'Lilita+One'], pacifico: ['Pacifico', 'Pacifico'], pixel: ['Press Start 2P', 'Press+Start+2P'], orbitron: ['Orbitron', 'Orbitron:wght@600;800'], poppins: ['Poppins', 'Poppins:wght@600;800'] };
  const fontFam = k => FONTS[k] ? `"${FONTS[k][0]}",system-ui,sans-serif` : '';
  const fontsLoaded = {};
  function loadFont(k) {
    if (!FONTS[k] || fontsLoaded[k]) return; fontsLoaded[k] = 1;
    const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = `https://fonts.googleapis.com/css2?family=${FONTS[k][1]}&display=swap`; document.head.appendChild(l);
  }
  function applyLook(L) {
    if (!L || !document.body) return; const b = document.body;
    b.className = b.className.replace(/\bws-\S+/g, '').trim() + ' ws-' + (L.widgetStyle || 'kaca');
    loadFont(L.font); b.style.fontFamily = fontFam(L.font);
    if (L.accent) b.style.setProperty('--acc', L.accent); else b.style.removeProperty('--acc');
  }
  if (window.io && !/\/(index\.html)?$/.test(location.pathname)) {
    try { const ls = io(); ls.on('settings', o => applyLook(o && o.look)); } catch (e) {}
  }

  window.RY = { fontFam, loadFont, applyLook, burst, q, $, esc, sleep, place, fmtNum, speak, playUrl, stopSpeech, connect };
})();
