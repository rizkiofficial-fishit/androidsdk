Efek suara di folder ini dibuat sendiri lewat sintesis (bukan rekaman/cuplikan pihak lain), bebas dipakai.
Untuk sound meme asli, upload sendiri lewat dashboard (tab Media / Sound Gift).
