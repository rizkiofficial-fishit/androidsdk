Musik latar di folder ini dibuat sendiri lewat sintesis (bukan cuplikan lagu pihak lain), bebas dipakai.
Upload mp3 kamu sendiri lewat tab Media untuk menambah lagu.
