# RYZFinity - TikTok LIVE tools (v2)

Mirip TikFinity, sekarang dengan fitur interaksi lengkap.

## Menjalankan
1. Butuh Node.js 20 atau lebih baru.
2. Di folder ini: `npm install` (kalau folder `node_modules` belum ada) lalu `npm start`
3. Buka http://localhost:3000, isi username TikTok, klik **Sambungkan Live** (akun harus sedang LIVE).
4. Di tab **Overlay** ada daftar URL + tombol salin. Pasang tiap URL sebagai Browser Source di OBS / TikTok LIVE Studio (1920x1080). Wajib pasang `alerts.html` supaya alert dan suara jalan. Aktifkan "Control audio via OBS" supaya suara ikut ke stream.

## Di hosting panel
- Upload zip, startup command: `node server.js` (atau `npm start`). Port otomatis dari variabel `PORT`.
- Variabel opsional:
  - `ADMIN_PASSWORD` : kunci dashboard (sangat disarankan kalau server bisa diakses publik). Overlay tetap terbuka supaya bisa dipakai di OBS.
  - `TIKTOK_USER` : otomatis konek ke username ini tiap server menyala.
  - `EULER_API_KEY` : kalau muncul error 'Failed to sign request' / 403 / limit (daftar gratis di eulerstream.com).
- Folder `data/` (pengaturan) dan `public/media/` (file upload) harus bisa ditulis dan sebaiknya persisten.

## Fitur
- **Suara (TTS)**: bacakan gift, follow, share, subscribe, penonton masuk, milestone like, dan komentar chat. Pilih mesin (suara perangkat atau Google lewat server), bahasa, suara, kecepatan, nada, volume, filter kata terlarang, buang link/emoji. Antrean otomatis, tidak saling tabrak.
- **Tampilan**: 7 tema alert (Klasik, Neon, Kaca, Emas, Pixel, Minimal, Gradien) dengan preview langsung. Gift biasa dan gift besar (batas diamond bisa diatur) bisa beda tema, ukuran, efek (menyala, confetti, getar), teks, dan suara.
- **Sound per gift**: pilih gift, pilih bunyinya, tanpa batas jumlah (ada tombol isi contoh 14 gift, dan daftar gift yang pernah masuk live tinggal klik). Bisa pakai min. diamond supaya gift mahal bunyinya beda. Ada **pustaka 28 SFX bawaan** (dibuat sendiri lewat sintesis: ding, kasir, tada, air horn, sad trombone, ba-dum-tss, bass drop, plus bunyi bergaya meme: boom dramatis, dun dun dun, bonk, bebek, kucing, womp womp, kaset digores, klakson, jangkrik, dll) + upload sound sendiri (mp3/wav/ogg/m4a) atau **impor dari link langsung .mp3** di tab Sound.
- **Musik & playlist**: buat playlist dari lagu bawaan atau mp3 upload sendiri, acak/ulang, volume otomatis mengecil saat alert atau TTS bunyi. Pasang `music.html` di OBS.
- **Pengingat otomatis**: ajakan berkala (misal "tap tap layarnya ya" atau "jangan lupa follow") yang tampil dan dibacakan selama live.
- **Komentar real-time** dengan foto profil, nama, @username, dan lencana MOD/SUB/GIFTER (dashboard dan overlay chat). TTS komentar bisa dibatasi: semua, follower, subscriber, moderator, atau yang pernah gift.
- **Alert & Sound** per event: teks, teks kecil, kalimat TTS, suara sendiri, lama tampil.
- **Gift Action**: reaksi khusus per gift (suara meme, gambar/GIF/video, teks, TTS) dengan syarat min. diamond.
- **Command Chat**: `!sosmed` dan sejenisnya, dengan balasan teks/suara/TTS dan jeda (cooldown).
- **Voting (poll)** lewat chat (ketik 1, 2, 3...), **Giveaway** (kata kunci atau undi dari yang sudah gift), **Timer** hitung mundur yang bisa nambah dari gift/follow/share.
- **Goal** diamond, like, follower; **Top** gifter/liker/komentar; **Statistik**; **Chat overlay**; **Overlay gabungan**.
- **Media**: upload suara/gambar/video dari dashboard.
- Pengaturan tersimpan di `data/settings.json`, sambung ulang otomatis kalau koneksi putus.
- Tombol tes, plus opsi **Simulasi** untuk mencoba goal/top/poll/giveaway/timer tanpa live.

## Opsi URL overlay
Semua widget: `?pos=tl|tr|bl|br|tc|bc|cl|cr|c` dan `?scale=1.5`
- `alerts.html?time=5`
- `chat.html?max=8&life=30&events=1&join=1`
- `goal.html?type=diamond|likes|followers` (gabungan: `type=diamond,likes,followers`)
- `top.html?type=gifters|likers|chatters&n=5`
- `stats.html?show=viewers,likes,followers,diamonds,shares,gifts`
- `music.html?np=0` (np=0 menyembunyikan kartu judul lagu)
- `chat.html?id=1&badges=all` (id=1 tampilkan @username, badges=0 sembunyikan lencana)
- `overlay.html?w=alerts,goal,poll,giveaway,timer,top,stats,chat,music`

## Catatan
- Suara Google memakai layanan tidak resmi dan butuh internet di server. Kalau gagal, otomatis pindah ke suara perangkat.
- Saat server menyala pertama kali, terminal mencetak contoh data tiap jenis event (`[contoh event: ...]`) untuk debug.

## Fitur streamer (v3)
- **Paket cepat** (tab Live): Gaming seru, Live jualan, Santai ngobrol. Sekali klik mengatur tema alert, sound gift, TTS, pengingat, dan command.
- **Soundboard**: tombol besar buat memutar SFX ke live, favorit bertanda bintang, tombol keyboard 1-9, plus kotak "Ketik lalu bacakan" (TTS manual). Butuh `alerts.html` terpasang.
- **Roda Putar**: overlay `wheel.html`. Diputar otomatis oleh gift tertentu (atau semua gift) atau manual, pemenang diumumkan lewat suara.
- **Rekap live**: unduh gambar PNG ringkasan sesi (diamond, like, follower, top gifter) buat story.

## Akun TikTok sendiri
- Tab Dashboard, kartu **Akun TikTok saya**: isi username, klik **Sambungkan akun saya**. Kalau belum live, tool menunggu dan nyambung sendiri begitu live dimulai (cek tiap 20 detik).
- Nyalakan *Otomatis konek saat server menyala* supaya langsung terpasang tiap server hidup (atau isi `TIKTOK_USER` di hosting).
- Membaca live tidak butuh password/login. Opsional login: isi variabel `TIKTOK_SESSIONID` dan `TIKTOK_TT_TARGET_IDC` (dari cookie `sessionid` dan `tt-target-idc` akun kamu). Jangan bagikan nilai ini ke siapa pun.

## Pakai di HP (PWA / APK)
- Buka dashboard di Chrome HP lewat link hosting (HTTPS), menu titik tiga, **Install app / Tambahkan ke layar utama**. Jadi ikon aplikasi sendiri.
- Untuk APK: buka pwabuilder.com, tempel link hosting HTTPS kamu, pilih Android, unduh paketnya.
- Suara alert diputar oleh halaman `alerts.html` (buka di tab/app lain di HP yang sama). Live TikTok dari HP tidak punya Browser Source, jadi suara keluar lewat speaker dan terdengar mic. Pakai speaker HP (jangan earphone) dan atur volume.
